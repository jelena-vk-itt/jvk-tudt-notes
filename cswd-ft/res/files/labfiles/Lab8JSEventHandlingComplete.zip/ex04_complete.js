function changeOldToNew() {
    document.getElementById('my_text_box2').innerHTML='Something new again!'
}

function toggleVisibilityOfMyTextBox2() {
    var isHidden = document.getElementById('my_text_box2').hidden;
    document.getElementById('my_text_box2').hidden = !isHidden;
}
