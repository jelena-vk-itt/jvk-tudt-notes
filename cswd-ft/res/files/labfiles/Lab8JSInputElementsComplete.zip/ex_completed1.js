function performOperation(opName) {
    // get numbers
    let a = parseInt(document.getElementById("num1").value);
    let b = parseInt(document.getElementById("num2").value);

    let r;
    
    // get result
    if (opName == "+") {
	r = a + b;
    } else if (opName == "-") {
	r = a - b;
    } else if (opName == "*") {
	r = a * b;
    } else if (opName == "/") {
	r = a / b;
    }

    document.getElementById("answer").innerHTML = r;
}

