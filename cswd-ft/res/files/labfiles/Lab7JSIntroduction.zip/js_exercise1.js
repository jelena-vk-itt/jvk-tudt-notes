 alert("Hello from the file exercise1.js!"); 
