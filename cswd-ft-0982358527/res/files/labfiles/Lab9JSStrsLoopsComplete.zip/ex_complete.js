function makeLetterList() {

    var word = document.getElementById("wordInput").value;

    var ulElementContentString = "";
    for (var i = 0; i < word.length; ++i) {
	var liElementString = "<li>" + word.charAt(i) + "</li>";
	ulElementContentString += liElementString;
    }

    document.getElementById("letterList").innerHTML = ulElementContentString;
}


function makeTable() {

    var word = document.getElementById("wordInput2").value;

    var i = 0;
    var tableContentString = "";
    while (i < word.length) {
	tableContentString += "<tr>";
	for (var j = 0; j < 5; ++j) {
	    var tableDataCellElementString = "<td>" + word.charAt(i) + "</td>";
	    tableContentString +=tableDataCellElementString;
	}
	tableContentString += "</tr>";
	++i;
    }

    document.getElementById("letterTable").innerHTML = tableContentString;
}
