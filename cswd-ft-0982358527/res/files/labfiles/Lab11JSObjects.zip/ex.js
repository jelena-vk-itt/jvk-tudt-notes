var friendsForTea = [
    { name: "Ali", beverage: "tea" },
    { name: "Ben", beverage: "coffee" },
    { name: "Con", beverage: "tea" },
    { name: "Dan", beverage: "tea" },
    { name: "Eva", beverage: "coffee" },
    { name: "Fog", beverage: "tea"}
];


    
