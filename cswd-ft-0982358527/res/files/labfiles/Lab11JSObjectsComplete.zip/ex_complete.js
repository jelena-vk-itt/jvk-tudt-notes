var friendsForTea = [
    { name: "Ali", beverage: "tea" },
    { name: "Ben", beverage: "coffee" },
    { name: "Con", beverage: "tea" },
    { name: "Dan", beverage: "tea" },
    { name: "Eva", beverage: "coffee" },
    { name: "Fog", beverage: "tea"}
];


function createOrders() {
    let orderText = "";
    for (let i = 0; i < friendsForTea.length; ++i) {
	orderText += "<li>" + friendsForTea[i].name + " would like " + friendsForTea[i].beverage + "</li>";

    }
    document.getElementById("beverage-orders").innerHTML = orderText;
}


document.querySelectorAll("#EX01 button")[0].addEventListener("click", createOrders);


function reshuffle() {

    friendsForTea.push({ name: "George", beverage: "tea"});
    friendsForTea[2].beverage = "coffee";
    friendsForTea[4].beverage = "tea";

    createOrders();
}

document.querySelectorAll("#EX01 button")[1].addEventListener("click", reshuffle);
