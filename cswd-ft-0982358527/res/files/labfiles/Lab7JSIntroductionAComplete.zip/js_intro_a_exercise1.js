 alert("Hello from the file js_intro_a_exercise1.js!"); 
