To use the offline notes and labs:
--> unzip the downloaded zip file
--> open cswd/index.html in a browser

Please note that both black-and-white and in-colour versions of the notes are available.
This version: COLOUR
