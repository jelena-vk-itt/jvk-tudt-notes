let data = {};

function saveData() {
    data.name = document.getElementById("name").value;
    data.surname = document.getElementById("surn").value;
    data.year = document.getElementById("year").value;
    data.programme = document.getElementById("prog").value;
}


function createMessage() {
    document.getElementById("message").innerHTML = "Hello " + data.name + " " + data.surname + ", welcome to year " + data.year + " of the " + data.programme + " programme at TU Dublin in Tallaght!";
}
