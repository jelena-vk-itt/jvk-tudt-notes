function printEven(max) {
    for (let i = 0; i < max; i +=2) {
	console.log(i);
    }
}

function appendSpace(str) {
    return str + " ";
}

function spaceOut() {
    let word = document.getElementById("word").value;
    let spacedElement = document.getElementById("spaced");
    spacedElement.innerHTML = "";
    for (let i = 0; i < word.length; ++i) {
	spacedElement.innerHTML += appendSpace(word.charAt(i));
    }
}

function populateTemplate() {
    let txtElement = document.getElementById('txt');
    txtElement.innerHTML = "";
    let numberOfParagraphs = +document.getElementById('num-pgphs').value;
    for (let i = 1; i <= numberOfParagraphs; ++i) {
	txtElement.innerHTML += "<p>Paragraph " + i + "</p>";
    }
}

