let started = false;
let count = 0;
let randomIndex = 0;

function onStart() {
    
    started = true;
    count = 0;
    randomIndex = Math.floor(Math.random() * 3);
    document.getElementById("box0").innerHTML="";
    document.getElementById("box1").innerHTML="";
    document.getElementById("box2").innerHTML="";
    document.getElementById("msg").innerHTML = "Click on the boxes to find the hidden picture";
    
}

function handleGuess(i) {
    
    if (started) {
	++count;
	if (i == randomIndex) {
	    document.getElementById("box" + i).innerHTML = "<img src='image.jpg'>";
	    document.getElementById("msg").innerHTML = "You've found it on guess " + count + "!";
	    started = false;
	} else {
	    document.getElementById("box" + i).innerHTML = "Not here";
	}
    }
    
}
