function writeGreeting() {
    document.getElementById("message").innerHTML = "Hello, my name is Jimmy Jones.";
}
function modifyBorderStyle(element_id) {
    document.getElementById(element_id).style.borderStyle = "dotted";
}