function get_shuffled_indices(n) { 
    const a = Array(n).fill().map((e, i) => i); 
    for (let l = n; l > 0; --l) { a.push(a.splice(Math.floor(Math.random() * l), 1)[0]); }
    return a;
}
let contents = ["Upside", "down", "tree", "and", "its", "hanging", "leaves"];
let vals = ["purple", "darkblue", "blue", "green", "yellow", "orange", "red"];


let currentClick = 0;
let order = get_shuffled_indices(7);
let elements = document.getElementsByClassName("elem");
for (let i = 0; i < 7; ++i) {
    let currEl = elements[order[i]];
    currEl.style.background = vals[i];
    currEl.addEventListener("click", function() { clicked(i); } );
}

function clicked(index) {
    if (index == currentClick) {
        if (currentClick == 6) {
            document.getElementById("message").innerHTML = "Well done! Reload the page to play again.";
        } else {
            ++currentClick;
            document.getElementById("message").innerHTML = index + 1;
        }
    } else {
        document.getElementById("message").innerHTML = "You have made a mistake. Reload the page to play again.";
    }
}

