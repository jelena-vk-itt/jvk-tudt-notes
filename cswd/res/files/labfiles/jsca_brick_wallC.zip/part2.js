const defs = {
    Upside : "Upper side of something",
    down : "Towards or at a lower place or position",
    tree : "A type of plant"
};


function getDefinition(word) {
    if (word in defs) {
        return defs[word];
    } else {
        return "";
    }
}

function processWord(str) {
    let definition = getDefinition(str);
    let inputVal = document.getElementById("some-text").value;
    if (inputVal == "upper") {
        definition = definition.toUpperCase();
    } else if (inputVal == "space") {
        definition = definition.replaceAll(" ", "&nbsp;&nbsp;&nbsp;");
    }
    document.getElementById("message").innerHTML = definition;
}

for (const element of document.getElementsByClassName("active")) {
    element.addEventListener("click", function () { processWord(this.innerHTML); });
    element.style.background = "darkgray";
}

