function buttonAction() {
    document.getElementById("rand-num").innerHTML = getRand1to10(); 
}

function getRand1to10() {
    let r = Math.floor(Math.random() * 10) + 1;
    return r;
}

function tripleRand() {
    document.getElementById("tripled").innerHTML = document.getElementById("rand-num").innerHTML * 3;
}
