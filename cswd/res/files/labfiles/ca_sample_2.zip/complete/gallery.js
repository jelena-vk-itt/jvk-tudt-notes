
// part 1
function smile() {
    document.getElementById("msg").innerHTML = ":-)";
}

function paint(colour) {

    document.getElementById("body").style.backgroundColor = colour;
}

// part 2
let colouredElements = document.querySelectorAll(".bg-info, .bg-warning, .bg-danger");
for (let e of colouredElements) {
    e.addEventListener("mouseout", function () { paint('white'); });
}

function list_text() {
    let writeTarget = document.getElementById("msg");
    writeTarget.innerHTML = "";

    let elems = document.getElementsByClassName("card");
    for (let e of elems) {
	writeTarget.innerHTML += e.innerHTML;
    }
}

document.addEventListener("keydown", list_text);

// part 3
let cards = document.getElementsByClassName("card");
let hide = true;
let index = 0;
function dis_app() {
    cards[index++].hidden = hide;
    if (index == cards.length) {
	hide = !hide;
	index = 0;
    }
}
document.querySelector("nav").addEventListener("click", dis_app);
