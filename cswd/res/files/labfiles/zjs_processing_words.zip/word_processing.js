function get_random_word(len) {
    const MIN_CHAR = 97;
    const NUM_CHARS = 26;

    let str = "";
    for (let i = 0; i < 5; ++i) {
	str += String.fromCharCode(MIN_CHAR + Math.random() * NUM_CHARS);
    }

    return str;
}

document.getElementById("the-word").innerHTML = get_random_word(5);

