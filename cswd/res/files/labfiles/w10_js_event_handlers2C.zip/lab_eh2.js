
// ex 1
function setBodyToInputColour() {
    document.getElementsByTagName("body")[0].style.background = document.getElementById("col-inp").value;
}

document.getElementById("colset-b").addEventListener("click", setBodyToInputColour);

// ex 2
function performOperation(opName) {
    
    let numbers = document.querySelectorAll("#calculator input");
    let a = +numbers[0].value;
    let b = +numbers[1].value;
    let r;
    
    // get result
    if (opName == "+") {
	r = a + b;
    } else if (opName == "-") {
	r = a - b;
    } else if (opName == "*") {
	r = a * b;
    } else if (opName == "/") {
	r = a / b;
    }

    document.querySelector("#calculator .answer").innerHTML = r;
}


var buttons = document.querySelectorAll("#calculator button");
for (let i = 0; i < buttons.length; ++i) {
    if (buttons[i].innerHTML == "Add") {
	buttons[i].addEventListener("click", function(){ performOperation("+"); });        
    } else if (buttons[i].innerHTML == "Subtract") {
	buttons[i].addEventListener("click", function(){ performOperation("-"); });        
    } else if (buttons[i].innerHTML == "Multiply") {
	buttons[i].addEventListener("click", function(){ performOperation("*"); });        
    } else if (buttons[i].innerHTML == "Divide") {
	buttons[i].addEventListener("click", function(){ performOperation("/"); });        
    }  
}
