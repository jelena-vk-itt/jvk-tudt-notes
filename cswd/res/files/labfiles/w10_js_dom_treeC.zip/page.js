
let body = document.getElementsByTagName("body")[0];

const article = document.createElement("article");
body.appendChild(article);

const h1 = document.createElement("h1");
article.appendChild(h1);
const h1Txt = document.createTextNode("In Brief");
h1.appendChild(h1Txt);

const p = document.createElement("p");
article.appendChild(p);
const text = document.createTextNode("This is a very short page. It includes some text, an image and a list.");
p.appendChild(text);

const img = document.createElement("img");
img.width = "120";
img.src = "https://jelena-vk-itt.github.io/jvk-tudt-notes/cswd/res/images/logo.png";
article.appendChild(img);

const h3 = document.createElement("h3");
article.appendChild(h3);
const h3Txt = document.createTextNode("TODO");
h3.appendChild(h3Txt);

const ul = document.createElement("ul");
article.appendChild(ul);
for (let liStr of ["finish lab", "practice", "practice some more" ]) {
    const li = document.createElement("li");
    ul.appendChild(li);
    const liTxt = document.createTextNode(liStr);
    li.appendChild(liTxt);
}

