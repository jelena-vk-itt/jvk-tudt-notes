const defs = {
    Upside : "Upper side of something",
    down : "Towards or at a lower place or position",
    tree : "A type of plant"
};

