

function lookupWord(word) {
    let tdCells = document.getElementsByTagName("td");

    for (let i = 0; i < tdCells.length; ++i) {
	if (tdCells.item(i).innerHTML.toLowerCase() == word.toLowerCase()) {
	    document.getElementById("lookup-result").innerHTML = tdCells.item(i+1).innerHTML;
	    break;
	}
    }
}


function lookupInput() {
    let inputWord = document.getElementsByTagName("input").item(0).value;

    lookupWord(inputWord);
}

function addEntry() {
    let inputs = document.getElementsByTagName("input");
    let newWord = inputs.item(0).value;
    let newDesc = inputs.item(1).value;

    let tdCells = document.getElementsByTagName("td");
    let wordArray = [];
    let descArray = [];    
    let index = 0;
    let newWordExists = false;
    while (index < tdCells.length) {
	let word = tdCells.item(index++).innerHTML;
	if (word.toLowerCase() == newWord.toLowerCase()) {
	    newWordExists = true;
	}
	wordArray.push(word);
	descArray.push(tdCells.item(index++).innerHTML);
    }

    let newTableContents = "<tr><th>word</th><th>description</th></tr>";

    if (!newWordExists) {
	wordArray.push(newWord);
	wordArray.sort(function (a, b) { return a.localeCompare(b); });
	let insertionIndex = wordArray.indexOf(newWord); 
	descArray.splice(insertionIndex, 0, newDesc);
    } else {
	let updateIndex = wordArray.indexOf(newWord);
	descArray[updateIndex] = newDesc;
    }
    
    for (let i = 0; i < wordArray.length; ++i) {
	newTableContents += "<tr><td>" + wordArray[i] + "</td><td>" + descArray[i] + "</td></tr>";	
    }
    
    document.getElementsByTagName("table").item(0).innerHTML = newTableContents;
}

document.getElementsByTagName("button").item(0).addEventListener("click", addEntry);
