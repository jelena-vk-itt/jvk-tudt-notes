
// 1
function processWord() {
    let word = document.getElementById("word-input").value.toUpperCase();

    //     process
    let newWord = "";
    for (letter of word) {
        newWord += letter;
        newWord += '-';
    }

    document.getElementById("word-output").innerHTML = newWord.slice(0, -1);
}

//3
var inputArray = [];

function writeList() {
    document.getElementById("list-pg").innerHTML = inputArray.join(' ');
}

function addToList() {
    let val = document.getElementById("list-item-input").value;
    if (val != "") { 
        inputArray.push(val);
    }

    writeList();
}

function removeFromList() {
    let val = document.getElementById("list-item-input").value;
    if (val != "") { 
        let index = inputArray.indexOf(val);
        if (index != -1) {
            inputArray.splice(index, 1);
        }
    }

    writeList();
}

function clearList() {
    inputArray = [];

    writeList();
}


// 4
var shelterAnimal = { species: "dog", name: "Bobby", age: 3, vaccinated: true };

function writeAnimalInfo() {
    let animalInfoListObj = document.getElementById("shelterAnimalInfo");
    animalInfoListObj.innerHTML = "";
    for (let property in shelterAnimal) {
        animalInfoListObj.innerHTML += "<li>" +  property + ": " +  shelterAnimal[property]  + "</li>";
    }
}

function correctInfo() {
    shelterAnimal.name = "Bobbie";
    shelterAnimal["adoptedBy"] = "Jane";
}

// 5a
function countButtons() {
    let buttonObjectArr = document.getElementsByTagName("button");
    
    document.getElementsByTagName("span")[0].innerHTML = buttonObjectArr.length;
}
countButtons();

// 5b

function changeToChapter() {
    let sectionObjects = document.getElementsByTagName("section");

    for (let obj of sectionObjects) {
	let newText = obj.innerHTML.replace("Part", "Chapter");
	obj.innerHTML = newText;
    }
}

function markImportant() {
    let importantSectionObjects = document.getElementsByClassName("important");

    for (let obj of importantSectionObjects) {
	obj.innerHTML = '<span style="color:red">IMPORTANT</span> ' + obj.innerHTML;
    }
}


let editingButtons = document.querySelectorAll(".editing button");
for (let button of editingButtons) {
    if (button.innerHTML == "Change to chapter") {
	button.addEventListener("click", changeToChapter);
    } else if (button.innerHTML == "Mark important") {
	button.addEventListener("click", markImportant);
    }
}

// 6
const alertButton = document.getElementById("alert").addEventListener("click", function() { alert("Hello!"); });


// 7
function addExerciseNumbers() {

    const horizontalLines = document.getElementsByTagName("hr");

    for (let i = 0; i < horizontalLines.length; i += 1) {
	let hr = horizontalLines[i];
	let parentEl = hr.parentElement;

	let newH3 = document.createElement('h3');
	newH3.innerHTML = i + 1;

	parentEl.insertBefore(newH3, hr);
    }
}


