

function lookupWord() {
    
    let inputWord = document.getElementsByTagName("input")[0].value;
    let tdCells = document.getElementsByTagName("td");

    // find  the object where we should write the definition and
    // set its contents to 'NOT FOUND'
    let definitionObject = document.getElementById("definition");
    definitionObject.innerHTML = "NOT FOUND";
    
    // we go up by two looking for the word, as the words are in cells 0, 2, 4
    for (let i = 0; i < tdCells.length; i += 2) {
	if (tdCells[i].innerHTML.toLowerCase() == inputWord.toLowerCase()) {
	    definitionObject.innerHTML = tdCells[i + 1].innerHTML;
	    break;
	}
    }
}

document.getElementsByTagName("button")[0].addEventListener("click", lookupWord);

function addEntry() {
    
    // the second and third input are for the new word and definition
    let inputs = document.getElementsByTagName("input");
    let newWord = inputs[1].value;
    let newDef = inputs[2].value;

    // prepare arrays where we will re-build the list of words and descriptions
    let wordArray = [];
    let defArray = [];    

    // we iterate through the cells going up by two, so that our index value
    // is always the index of a word (rather than a definition)
    let newWordAdded = false;
    let tdCells = document.getElementsByTagName("td");
    for (let index = 0; index < tdCells.length; index += 2) {

	let currWord = tdCells[index].innerHTML;
	let currDef = tdCells[index + 1].innerHTML;

	// if the new word comes after the current one alphabetically
	// then we only need to add the current word to the list and
	// the new word will be added in some subsequent iteration;
	// we compare the lowercase version of the words, to make the
	// function case-insensitive
	if (newWord.toLowerCase() > currWord.toLowerCase()) {
	    wordArray.push(currWord);
	    defArray.push(currDef);
	}
	// if the new word is the same as the old word, then we add
	// only the new word to the list as it is an update of the old one;
	// we also set the flag indicating that the new word was added
	else if (newWord.toLowerCase() === currWord.toLowerCase()) {
	    wordArray.push(newWord);
	    defArray.push(newDef);
	    newWordAdded = true;
	}
	// if the new word is before the current one alphabetically
	// (the remaining case of the conditional), we need to check
	// whether the new word has already been added (this would have
	// happened if the new word comes before some earlier word)
	// and if not, add it and set the flag indicating that the 
	// new word was added, so that it is not added again in a
	// further iteration; the current word is added in any case
	else {
	    if (!newWordAdded) {
		wordArray.push(newWord);
		defArray.push(newDef);
		newWordAdded = true;
	    }

	    wordArray.push(currWord);
	    defArray.push(currDef);
	}
    }

    // if the new word comes at the end of the dictionary, then it will
    // not have been added yet and we need to add it now, at the end
    // of the list
    if (!newWordAdded) {
	wordArray.push(newWord);
	defArray.push(newDef);
    }	

    // put together the new table contents
    let newTableContents = "<tr><th>word</th><th>description</th></tr>";
    for (let i = 0; i < wordArray.length; ++i) {
	newTableContents += "<tr><td>" + wordArray[i] + "</td><td>" + defArray[i] + "</td></tr>";	
    }
    
    document.querySelector("table").innerHTML = newTableContents;
}

document.getElementsByTagName("button")[1].addEventListener("click", addEntry);

