function get_shuffled_indices(n) { 
    const a = Array(n).fill().map((e, i) => i); 
    for (let l = n; l > 0; --l) { a.push(a.splice(Math.floor(Math.random() * l), 1)[0]); }
    return a;
}
let contents = ["Upside", "down", "tree", "and", "its", "hanging", "leaves"];
let vals = ["purple", "darkblue", "blue", "green", "yellow", "orange", "red"];

