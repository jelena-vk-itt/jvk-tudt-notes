function get_random_word(len) {
    const MIN_CHAR = 97;
    const NUM_CHARS = 26;

    let str = "";
    for (let i = 0; i < 5; ++i) {
	str += String.fromCharCode(MIN_CHAR + Math.random() * NUM_CHARS);
    }

    return str;
}

document.getElementById("the-word").innerHTML = get_random_word(5);



// ======================= part 1a =======================
function get_first_letter() {
    let letter = document.getElementById("the-word").innerHTML[0];
    document.getElementById("first-letter").innerHTML = letter;
    console.log("The first letter is " + letter);
}

// ======================= part 1b =======================
function get_letter(text, index) {
    if (index >= 0 && index < text.length) {
	return text[index];
    } else {
	return '?';
    }
}

function decode() {
    let inputs = document.getElementsByClassName("decoder-input");
    let words = inputs[0].value.split(" ");
    let numbers = inputs[1].value.split(" ");
    let output = "";
    for (let i = 0; i < words.length; ++i) {
	output += get_letter(words[i], parseInt(numbers[i]));
    }
    document.getElementById("decoded").innerHTML = output;
}

// ======================= part 2 =======================
function count_letter(text, letter) {
    if (letter.length < 1) {
	return 0;
    }
    return text.split(letter[0]).length - 1;

    // or, more directly but more 'complicatedly':
    //
    // let count = 0;
    // let index = 0;
    // let indexInSlice = -1;
    // while ((indexInSlice = text.slice(index).indexOf(letter[0])) != -1) {
    // 	index += indexInSlice + 1;
    // 	++count;
    // }
    // return count;
}

function count_vowels() {
    let text = document.querySelector("#count-vowels input").value;
    let headerCells = document.querySelectorAll("#count-vowels table th");
    let dataCells = document.querySelectorAll("#count-vowels table td");
    for (let i = 0; i < headerCells.length; ++i) {
	dataCells[i].innerHTML = count_letter(text, headerCells[i].innerHTML);
    }
}

document.querySelector("#count-vowels button").addEventListener("click", count_vowels);


