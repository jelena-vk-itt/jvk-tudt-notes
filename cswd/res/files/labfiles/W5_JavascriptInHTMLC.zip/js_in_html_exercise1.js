 alert("Hello from the file js_b_in_html_exercise1.js!"); 
