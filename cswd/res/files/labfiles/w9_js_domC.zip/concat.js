function concatenateInputs() {
    let inputs = document.getElementsByTagName("input");
    let result = "";
    for (input of inputs) {
	result += input.value;
    }

    let resultClassElements = document.getElementsByClassName("result");
    resultClassElements[0].innerHTML = result;
}
