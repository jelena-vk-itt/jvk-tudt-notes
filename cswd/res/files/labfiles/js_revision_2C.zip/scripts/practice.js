
// 1
function processWord() {
    let word = document.getElementById("word-input").value.toUpperCase();

    //     process
    let newWord = "";
    for (letter of word) {
        newWord += letter;
        newWord += '-';
    }

    document.getElementById("word-output").innerHTML = newWord.slice(0, -1);
}

//3
var inputArray = [];

function writeList() {
    document.getElementById("list-pg").innerHTML = inputArray.join(' ');
}

function addToList() {
    let val = document.getElementById("list-item-input").value;
    if (val != "") { 
        inputArray.push(val);
    }

    writeList();
}

function removeFromList() {
    let val = document.getElementById("list-item-input").value;
    if (val != "") { 
        let index = inputArray.indexOf(val);
        if (index != -1) {
            inputArray.splice(index, 1);
        }
    }

    writeList();
}

function clearList() {
    inputArray = [];

    writeList();
}


// 4
var shelterAnimal = { species: "dog", name: "Bobby", age: 3, vaccinated: true };

function writeAnimalInfo() {
    let animalInfoListObj = document.getElementById("shelterAnimalInfo");
    animalInfoListObj.innerHTML = "";
    for (let property in shelterAnimal) {
        animalInfoListObj.innerHTML += "<li>" +  property + ": " +  shelterAnimal[property]  + "</li>";
    }
}

function correctInfo() {
    shelterAnimal.name = "Bobbie";
    shelterAnimal["adoptedBy"] = "Jane";
}

// 5a
function countButtons() {
    let buttonObjectArr = document.getElementsByTagName("button");
    
    document.getElementsByTagName("span")[0].innerHTML = buttonObjectArr.length;
}
countButtons();

// 5b

function changeToChapter() {
    let sectionObjects = document.getElementsByTagName("section");

    for (let obj of sectionObjects) {
	let newText = obj.innerHTML.replace("Part", "Chapter");
	obj.innerHTML = newText;
    }
}

function markImportant() {
    let importantSectionObjects = document.getElementsByClassName("important");

    for (let obj of importantSectionObjects) {
	obj.innerHTML = '<span style="color:red">IMPORTANT</span> ' + obj.innerHTML;
    }
}


let editingButtons = document.querySelectorAll(".editing button");
for (let button of editingButtons) {
    if (button.innerHTML == "Change to chapter") {
	button.addEventListener("click", changeToChapter);
    } else if (button.innerHTML == "Mark important") {
	button.addEventListener("click", markImportant);
    }
}
