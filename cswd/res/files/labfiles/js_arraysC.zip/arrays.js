

// EXERCISE 1
// 1
let toolArray = ['jigsaw', 'hammer', 'pliers', 'hacksaw', 'spanner', 'screwdriver'];

// 2
toolArray.push('level');

// 3
toolArray.pop()
toolArray.pop()

// 4
toolArray.sort()

// 5
toolArray.reverse()

// 6
toolArray[2] = 'plane'

// 7
toolArray.splice(1, 1)


// EXERCISE 2
function makeTCOrderListFromInputs() {
    let ulContents = "";
    let names = document.getElementById("names-input").value.split(" ");
    let tcStr = document.getElementById("tc-input").value;

    // create the list only if it is not an empty string of names
    if (names.length > 1 || names[0] != "") {
	for (let i = 0; i < names.length; ++i) {
	    let drink = "nothing";
	    if (tcStr[i] == 'T') {
		drink = "tea";
	    } else {
		drink = "coffee";
	    }
	    
	    ulContents += "<li>" + names[i] + " would like " + drink + ".</li>";
	}
    }

    // we always have to write to the element, because if the input with names
    // is empty we also want the list to be empty
    document.getElementById("order-list").innerHTML = ulContents;
}
