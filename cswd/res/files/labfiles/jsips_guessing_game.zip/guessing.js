let started = false;
let count = 0;
let randomIndex = 0;

function onStart() {
}

function handleGuess(i) {
}
