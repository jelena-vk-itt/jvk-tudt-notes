function populateTable() {
    let t = document.getElementById('the-table');
    const letters = "abcde";
    for (let i = 1; i < 6; ++i) {
	let rowHtml = "<tr>";
	for (let l = 0; l < letters.length; ++l) {
	    rowHtml += "<td>" + letters[l] + i + "</td>";
	}
	rowHtml += "</tr>";
	t.innerHTML += rowHtml;
    }
}

