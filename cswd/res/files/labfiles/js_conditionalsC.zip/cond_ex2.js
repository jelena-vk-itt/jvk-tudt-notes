
function performOperation(operation) {
    let x = +document.getElementById('num1').value;
    let y = +document.getElementById('num2').value;
    let res = undefined;
    if (operation == '+') {
	res = x + y;
    } else if (operation == '-') {
	res = x - y;
    } else if (operation == '*') {
	res = x * y;
    } else if (operation == '/') {
	res = x / y;
    }
    document.getElementById('answer').innerHTML = res;
}


