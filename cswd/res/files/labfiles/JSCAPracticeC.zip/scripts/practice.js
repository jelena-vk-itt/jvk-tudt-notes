// 2
// alert("Hello from practice file!");
console.log("Hello from practice file!");

// 3a
// alert();


// 4b
function doubleTheNumber(num) {
    console.log(num * 2);
}

// 5 
function writeMyTextToConsole() {
    console.log(document.getElementById("my-text").innerHTML);
}

// 6
function writeHoHoToDestination1() {
    document.getElementById("text-destination-1").innerHTML = "Ho ho ho here we go";
}

// 8
function readTextInput() {
    console.log(document.getElementById("input-text").value);
}

// 11
function doubleInputAndWriteOut() {
    document.getElementById("double-number").innerHTML = +document.getElementById("a-number").value * 2;
}

// 12
document.getElementById("my-box").style.background = 'lightsalmon';
let isSalmon = true;
function toggleBackground() {
    if (isSalmon) {
        document.getElementById("my-box").style.background = 'lightblue';
        isSalmon = false;
    } else {
        document.getElementById("my-box").style.background = 'lightsalmon';
        isSalmon = true;
    }
}

// 13
function processWord() {
    let word = document.getElementById("word-input").value.toUpperCase();

    //     process
    let newWord = "";
    for (letter of word) {
        newWord += letter;
        newWord += '-';
    }

    document.getElementById("word-output").innerHTML = newWord.slice(0, -1);
}

//15
var inputArray = [];

function writeList() {
    document.getElementById("list-pg").innerHTML = inputArray.join(' ');
}

function addToList() {
    let val = document.getElementById("list-item-input").value;
    if (val != "") { 
        inputArray.push(val);
    }

    writeList();
}

function removeFromList() {
    let val = document.getElementById("list-item-input").value;
    if (val != "") { 
        let index = inputArray.indexOf(val);
        if (index != -1) {
            inputArray.splice(index, 1);
        }
    }

    writeList();
}

function clearList() {
    inputArray = [];

    writeList();
}


// 16
var shelterAnimal = { species: "dog", name: "Bobby", age: 3, vaccinated: true };

function writeAnimalInfo() {
    let animalInfoListObj = document.getElementById("shelterAnimalInfo");
    animalInfoListObj.innerHTML = "";
    for (let property in shelterAnimal) {
        animalInfoListObj.innerHTML += "<li>" +  property + ": " +  shelterAnimal[property]  + "</li>";
    }
}

function correctInfo() {
    shelterAnimal.name = "Bobbie";
    shelterAnimal["adoptedBy"] = "Jane";
}

// 17
function countButtons() {
    let buttonObjectArr = document.getElementsByTagName("button");
    
    document.getElementsByTagName("span")[0].innerHTML = buttonObjectArr.length;
}
countButtons();