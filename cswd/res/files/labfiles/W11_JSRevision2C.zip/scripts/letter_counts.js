function count_letters() {

    const alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    let counts = new Array(26).fill(0);
    // alternatively, you can use the folowing, clearer but more cumbersome expression:
    // let array = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

    // first we count the different letters
    let text = document.querySelector("input").value;
    for (let character of text) {
	// check if the character is in the alphabet
	let index = alphabet.indexOf(character);
	if (index != -1) {
	    // increment the count at the modulo of index by 26 (so that
	    // index becomes 0 if the character is uppercase A
	    // index becomes 1 if the character is uppercase B etc.)
	    ++counts[index % 26];
	}
    }

    // now we will write the table
    let tableRows = ["<tr>", "<tr>"];
    for (let i = 0; i < 26; ++i) {
	// add the current letter to the first row
	tableRows[0] += "<td>" + alphabet[i] + "</td>";

	// add the count for the current letter to the second row
	tableRows[1] += "<td>" + counts[i] + "</td>";
    }

    // put in the close tags
    tableRows[0] += "</tr>";
    tableRows[1] += "</tr>";
	

    // put the row HTML into the table on the page
    document.querySelector("table").innerHTML = tableRows[0] + tableRows[1];
}

document.querySelector("button").addEventListener("click", count_letters);
    

