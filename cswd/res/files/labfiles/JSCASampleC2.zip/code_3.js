
function lookupWord(word) {
    // find cell with word
    let tdArray = document.getElementsByTagName("td");

    for (let index = 0; index < tdArray.length; ++index) {
        if (tdArray[index].innerHTML == word) {
            document.getElementById("lookup-result").innerHTML = tdArray[index + 1].innerHTML;
            break;
        }
    }
}

function lookupInput() {
    lookupWord(document.getElementsByTagName("input")[0].value);
}

function addEntry_old() {
    let inputElements = document.getElementsByTagName("input");
    let rowHTML = "<tr><td>" + inputElements[0].value + "</td><td>" + inputElements[1].value + "</td></tr>";

    document.getElementsByTagName("table")[0].innerHTML += rowHTML;
}

function addEntry() {
    let inputElements = document.getElementsByTagName("input");
    let newInnerHTML = "<td>" + inputElements[0].value + "</td><td>" + inputElements[1].value + "</td>";

    let rowElements = document.getElementsByTagName("tr");
    let rowInnerHTMLs = [];
    for (let index = 1; index < rowElements.length; ++index) {
        rowInnerHTMLs.push(rowElements[index].innerHTML)
    }
    rowInnerHTMLs.push(newInnerHTML);
    rowInnerHTMLs.sort();

    let tabEl = document.getElementsByTagName("table")[0];
    tabEl.innerHTML = "<tr>" + rowElements[0].innerHTML + "</tr>";
    for (rih of rowInnerHTMLs) {
        tabEl.innerHTML += "<tr>" + rih + "</tr>";
    }
}

document.getElementsByTagName("button")[1].addEventListener("click", addEntry);
