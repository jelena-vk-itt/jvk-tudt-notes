
function lookupWord(word) {
    // find cell with word
    let tdArray = document.getElementsByTagName("td");

    for (let index = 0; index < tdArray.length; ++index) {
        if (tdArray[index].innerHTML == word) {
            document.getElementById("lookup-result").innerHTML = tdArray[index + 1].innerHTML;
            break;
        }
    }
}

function lookupInput() {
    lookupWord(document.getElementsByTagName("input")[0].value);
}