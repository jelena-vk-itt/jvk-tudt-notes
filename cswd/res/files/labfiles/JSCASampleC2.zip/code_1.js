

function lookupDog() {
    // read contents from id dog-description
    let ddcont = document.getElementById("dog-description").innerHTML;
    
    // set innerHTML of el with id lookup-result to what was just read
    document.getElementById("lookup-result").innerHTML = ddcont;

    logLength(ddcont.length);
}

function logLength(len) {
    console.log("The length is " + len);  
}


