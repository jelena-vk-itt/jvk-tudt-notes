function lookupDog() {
    let dogDesc = document.getElementById("dog-description").innerHTML;
    document.getElementById("lookup-result").innerHTML = dogDesc;

    logLength(dogDesc.length);
}

function logLength(len) {
    console.log("The length is " + len);
}