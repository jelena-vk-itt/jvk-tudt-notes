/* In the Javascript file define a function called lookupWord with one parameter called word. The function should search the table for the cell containing word, then read the contents of the following cell (the description) and set them as the contents of the span element beside the text "Lookup result: ". (Tip: To access the td elements, you can use the document method getElementsByTagName() and iterate through the result to look for the word and read the following item.)
*/

function lookupWord(word) {
    let description = "";
    
    // get all the td elements
    let tdElementArray = document.getElementsByTagName("td");
    for (let index = 0; index < tdElementArray.length; ++index) {
        if (word == tdElementArray[index].innerHTML) {
            description = tdElementArray[index + 1].innerHTML;
            break;
        }
    }

    document.getElementById("lookup-result").innerHTML = description;
}

function lookupInput() {
    // let inputEl = document.getElementsByTagName("input")[0];
    let inputEl = document.querySelector("input");
    lookupWord(inputEl.value);
}


