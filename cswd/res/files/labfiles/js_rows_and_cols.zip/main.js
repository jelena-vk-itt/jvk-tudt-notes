const ROWS = 3;
const COLS = 3;

function get_index(row, col) { return row * COLS + col; }



function setColourInRowAndCol(row, col) {

}

