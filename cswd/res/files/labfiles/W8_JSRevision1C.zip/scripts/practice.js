// 2
// alert("Hello from practice file!");
console.log("Hello from practice file!");

// 3a
// alert();


// 4b
function doubleTheNumber(num) {
    console.log(num * 2);
}

// 5 
function writeMyTextToConsole() {
    console.log(document.getElementById("my-text").innerHTML);
}

// 6
function writeHoHoToDestination1() {
    document.getElementById("text-destination-1").innerHTML = "Ho ho ho here we go";
}

// 8
function readTextInput() {
    console.log(document.getElementById("input-text").value);
}

// 11
function doubleInputAndWriteOut() {
    document.getElementById("double-number").innerHTML = +document.getElementById("a-number").value * 2;
}

// 12
document.getElementById("my-box").style.background = 'lightsalmon';
let isSalmon = true;
function toggleBackground() {
    if (isSalmon) {
        document.getElementById("my-box").style.background = 'lightblue';
        isSalmon = false;
    } else {
        document.getElementById("my-box").style.background = 'lightsalmon';
        isSalmon = true;
    }
}
