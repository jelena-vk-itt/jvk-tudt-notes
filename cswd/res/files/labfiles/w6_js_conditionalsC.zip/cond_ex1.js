function toggleHelloButtonDisabled() {
    let button = document.getElementById("hello-button");
    if (button.disabled) {
	button.disabled = false;
    } else {
	button.disabled = true;
    }
}
	
