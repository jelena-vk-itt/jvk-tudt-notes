
function colourByNumbers() {

    let inputElements = document.getElementsByTagName("input");
    let numbers = inputElements[0].value.split(" ");
    let colour = inputElements[1].value;

    let hundredElements = document.querySelectorAll("div>button");
    for (let numStr of numbers) {
	let index = + numStr - 1; 
	if (index >= 0 && index < 100) { 
	    hundredElements[index].style.backgroundColor = colour;
	}
    }
}

document.querySelector("p>button").addEventListener("click", colourByNumbers);
