
function makeLastButtonBlue() {
    document.getElementById("last-button").style.backgroundColor = "blue";
}

function writeToButton37(text) {
    document.getElementById("button-three-seven").innerHTML = text;
}
