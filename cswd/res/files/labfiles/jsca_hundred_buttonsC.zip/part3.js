function getRandomColour() {
    return "rgb(" +
	Math.floor(Math.random() * 256) +
	", " +
	Math.floor(Math.random() * 256) +
	", " +
	Math.floor(Math.random() * 256) +
	")";
}

let matrixButtons = document.querySelectorAll("div>button");
function drawShape(shape) {
    
    for (let i = 0; i < 100; ++i) {
	matrixButtons[i].style.backgroundColor = 'lightgray';
    }
    
    if (shape == 'sq') {
	for (let i = 0; i < 10; i += 9) {
	    for (let j = 0; j < 10; ++j) {
		let n = i * 10 + j;
		let m = i + j * 10;
		matrixButtons[n].style.backgroundColor = getRandomColour();
		matrixButtons[m].style.backgroundColor = getRandomColour();
	    }
	}	
    } else if (shape == 'x') {
	for (let i = 0; i < 10; ++i) {
	    let n = i * 11;
	    let m = 10 * i + 9 - i;
	    matrixButtons[n].style.backgroundColor = getRandomColour();
	    matrixButtons[m].style.backgroundColor = getRandomColour();
	}
    } 
}

let clickButtons = document.querySelectorAll("p>button");
clickButtons[0].addEventListener("click", function(){ drawShape('sq'); });
clickButtons[1].addEventListener("click", function(){ drawShape('x'); });
clickButtons[2].addEventListener("click", function(){ drawShape(''); });
