let s1="Hello"
let s2="there"
function concatenateStrings(a, b) {
    return a + b;
}
