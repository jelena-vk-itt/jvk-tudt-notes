function modifyPage() {

    // ------------ Appending a child node --------------
    // create the element object
    let newP = document.createElement('p');

    // create the text node object
    let newTxt = document.createTextNode("This ends the article.");

    // add the text node object as the last child of the new paragraph object
    newP.appendChild(newTxt);

    // add the paragraph element object as the last child of the article
    document.body.children[0].appendChild(newP);


    // ------------- Removing a child node ----------------
    // access the element we want to remove
    let elementToRemove = document.body.children[0].children[3].children[0];

    // parent of the element to remove
    let parent = elementToRemove.parentElement;

    // remove the element
    parent.removeChild(elementToRemove);


    // ------------- Inserting a child node ----------------
    // access the element we want to remove
    let secondListItem = document.body.children[0].children[3].children[1];

    // create a new list item element
    let newLI = document.createElement('li');

    // rather than creating and adding a text node,
    //we can set the innerText property on the element
    newLI.innerText = "It is important to be inclusive";

    // insert the node
    secondListItem.parentElement.insertBefore(newLI, secondListItem);


    // ------------- Replacing a child node ----------------
    // create the new paragraph
    let newEndingParagraph = document.createElement('p');
    newEndingParagraph.appendChild(document.createTextNode('We hope you liked this article.'));

    // access the article element
    let article = document.body.children[0];

    // access the last element in the article
    let indexOfLastArticleElement = article.children.length - 1;
    let lastArticleElement = article.children[indexOfLastArticleElement];

    // replace the old paragraph with the new one
    article.replaceChild(newEndingParagraph, lastArticleElement);
}

document.addEventListener("keypress", modifyPage);