
// ex 1
function fetchInfo(id) {
}


// ex 2
function listEntries() {
}

