

function write_content(type) {
    let contentElement = document.getElementById("content"); 
    if (type == "events") {
	contentElement.innerHTML = "Exciting new exhibition by Galwegian artist Bella Black.";
    } else if (type == "news") {
	contentElement.innerHTML = "Coming soon: our outdoor exhibition space, 'the yard'.";
    } else if (type == "info") {
	contentElement.innerHTML = "Opening times: 8am to 8pm, Tuesday to Sunday.";
    } else {
	contentElement.innerHTML = "";
    }
}

let rbyClasses = ['bg-info', 'bg-danger', 'bg-warning'];
let nextRBYClasses = ['bg-danger', 'bg-warning', 'bg-info'];
let rbyElementArray = document.querySelectorAll("." + rbyClasses.join(", ."));
let rbyElementCount = rbyElementArray.length;

function change_colours() {
    rbyElementArray.forEach(function (e) {
	let elementClassList = e.classList;
	for (let i = 0; i < rbyClasses.length; ++i) {
	    if (elementClassList.contains(rbyClasses[i])) {
		elementClassList.remove(rbyClasses[i]);
		elementClassList.add(nextRBYClasses[i]);
		break;
	    }
	}		   	    
    });
}

rbyElementArray.forEach(function (e) { e.addEventListener("click", change_colours); });
