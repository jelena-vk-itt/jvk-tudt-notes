
// An object representing the current active button (the red button), if there is one. We begin with none.
var currentActiveButton = null;
// The count of clicks on red buttons. We start with 0.
var count = 0;
var beginTime = null;

function startGame() {
    count = 0;
    beginTime = new Date();
    document.getElementById("result").innerHTML = "";
    buttonHop();
}

function endGame() {
    clearCurrentActiveButton();
    let timeItTook = new Date() - beginTime;
    document.getElementById("result").innerHTML = "Your time: " + timeItTook/1000 + " seconds";
}

// clearCurrentActiveButton() should render the current active (red) button inactive

// buttonHop() should handle the click on the active (red) button
