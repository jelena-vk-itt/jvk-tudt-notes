


function setColour(buttonName, colour) {
    var buttons = document.getElementsByTagName("button");
    for (var i = 0; i < buttons.length; ++i) {
	if (buttons.item(i).innerHTML == buttonName) {
	    buttons.item(i).style.background = colour;
	}
    }
}


function setColourFromInput() {
    var inputs = document.getElementsByTagName("input");
    setColour(inputs.item(0).value, inputs.item(1).value);
}
