

function getLastButtonName() {
    var lastButtonName = document.getElementById("last-button").innerHTML;
    document.getElementById("namefetch-result").innerHTML = lastButtonName;
    logLength(lastButtonName.length);
}

function logLength(len) {
    console.log("The length is " + len);
}
