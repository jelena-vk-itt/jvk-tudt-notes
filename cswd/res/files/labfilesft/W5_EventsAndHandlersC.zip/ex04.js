function renew() {
    document.getElementById('my_other_text_box').innerHTML = 'Something even newer';
}

function hideMyOtherTextBox() {
    document.getElementById('my_other_text_box').hidden = true;
}
