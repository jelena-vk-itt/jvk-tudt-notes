To use the offline notes and labs:
--> unzip the downloaded zip file
--> open cswd-pt-1239404852/index.html in a browser

Please note that both black-and-white and in-colour versions of the notes are available.
This version: BLACK AND WHITE
