function fetchInfo(id) {
}

function listSections() {
}
