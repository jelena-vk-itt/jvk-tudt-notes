function lookupCar() {
    var carDescText = document.getElementById("car-description").innerHTML;
    document.getElementById("lookup-result").innerHTML = carDescText;
    logLength(carDescText.length);
}

function logLength(len) {
    console.log("The length is " + len);
}
