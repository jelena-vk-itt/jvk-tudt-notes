
// An object representing the current active button (the red button), if there is one. We begin with none.
var currentActiveButton = null;
// The count of clicks on red buttons. We start with 0.
var count = 0;
var beginTime = null;

function startGame() {
    count = 0;
    beginTime = new Date();
    document.getElementById("result").innerHTML = "";
    buttonHop();
}

function endGame() {
    clearCurrentActiveButton();
    let timeItTook = new Date() - beginTime;
    document.getElementById("result").innerHTML = "Your time: " + timeItTook/1000 + " seconds";
}

// clearCurrentActiveButton() should render the current active (red) button inactive
function clearCurrentActiveButton() {
    if (currentActiveButton != null) {
	currentActiveButton.style.background = 'white';
	currentActiveButton.removeEventListener("click", buttonHop);
    }
}

// buttonHop() should handle the click on the active (red) button
function buttonHop() {
    if (++count > 10) {
	endGame();
    } else {
	clearCurrentActiveButton();
	
	let newActiveIndex = Math.floor(Math.random() * 9);
	currentActiveButton = document.getElementsByTagName("button").item(newActiveIndex);
	
	currentActiveButton.style.background = 'red';
	currentActiveButton.addEventListener("click", buttonHop);
    }
}

