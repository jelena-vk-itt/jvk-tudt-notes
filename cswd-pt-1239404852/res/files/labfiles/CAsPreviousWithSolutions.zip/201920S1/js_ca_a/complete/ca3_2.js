

function lookupWord(word) {
    let tdCells = document.getElementsByTagName("td");

    for (let i = 0; i < tdCells.length; ++i) {
	if (tdCells.item(i).innerHTML.toLowerCase() == word.toLowerCase()) {
	    document.getElementById("lookup-result").innerHTML = tdCells.item(i+1).innerHTML;
	    break;
	}
    }
}


function lookupInput() {
    let inputWord = document.getElementsByTagName("input").item(0).value;

    lookupWord(inputWord);
}
