function lookupDog() {
    var dogDescText = document.getElementById("dog-description").innerHTML;
    document.getElementById("lookup-result").innerHTML = dogDescText;
    logLength(dogDescText.length);
}

function logLength(len) {
    console.log("The length is " + len);
}
