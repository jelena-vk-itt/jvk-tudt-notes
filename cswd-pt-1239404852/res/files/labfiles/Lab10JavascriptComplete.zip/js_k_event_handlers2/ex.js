function changeBodyColour() {
    document.getElementsByTagName("body")[0].style.background =
	"rgb(" +
	Math.floor(Math.random() * 255) +
	", " +
	Math.floor(Math.random() * 255) +
	", " +
	Math.floor(Math.random() * 255) +
	")";
}

function activateColourChangingButton() {
    document.getElementById("chgbdycol").addEventListener("click", changeBodyColour);
}

function deactivateColourChangingButton() {
    document.getElementById("chgbdycol").removeEventListener("click", changeBodyColour);
}

/* EXERCISE EX01 */
function resetBodyColour() {
    document.getElementsByTagName("body")[0].style.background = 'lightgray';
}
/* EXERCISE EX01 END */


function changeBodyToSpecifiedColour(colour) {
   document.getElementsByTagName("body")[0].style.background = colour;
}

document.getElementById("reset").addEventListener("click", resetBodyColour);
document.getElementById("makered").addEventListener("click", function() { changeBodyToSpecifiedColour("red"); });


// EXERCISE EX02
function performOperation(opName) {
    // get numbers
    let numbers = document.querySelectorAll("#calculator input");
    let a = parseInt(numbers[0].value);
    let b = parseInt(numbers[1].value);
    let r;
    
    // get result
    if (opName == "+") {
	r = a + b;
    } else if (opName == "-") {
	r = a - b;
    } else if (opName == "*") {
	r = a * b;
    } else if (opName == "/") {
	r = a / b;
    }

    document.querySelector("#calculator .answer").innerHTML = r;
}


var buttons = document.querySelectorAll("#calculator button");
for (let i = 0; i < buttons.length; ++i) {
    if (buttons[i].innerHTML == "Add") {
	buttons[i].addEventListener("click", function(){ performOperation("+"); });        
    } else if (buttons[i].innerHTML == "Subtract") {
	buttons[i].addEventListener("click", function(){ performOperation("-"); });        
    } else if (buttons[i].innerHTML == "Multiply") {
	buttons[i].addEventListener("click", function(){ performOperation("*"); });        
    } else if (buttons[i].innerHTML == "Divide") {
	buttons[i].addEventListener("click", function(){ performOperation("/"); });        
    }  
}

// EXERCISE EX02 END
