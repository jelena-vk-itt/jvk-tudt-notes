// Exercise 1 EX01
function fetchInfo(id) {
    document.getElementById("info-box").innerHTML = document.getElementById(id).innerHTML;
}


// Exercise 2 EX02
function listSections() {
    var sections = document.getElementsByTagName("section");
    var idList = "";

    for (var i = 0; i < sections.length; ++i) {

	idList += sections.item(i).id;
	idList += "<br/>";
    }

    document.getElementById("target-paragraph").innerHTML = idList;
}


// Exercise 3 EX03
function listAnimalSpeciesByClass() {
    let mammalElements = document.getElementsByClassName("mammal");
    let mammalListElement = document.getElementById("m-list");
    for (let i = 0; i < mammalElements.length; ++i) {
	mammalListElement.innerHTML += " " + mammalElements[i]["id"];
    }

    let reptileElements = document.getElementsByClassName("reptile");
    let reptileListElement = document.getElementById("r-list");

    for (let i = 0; i < reptileElements.length; ++i) {
	reptileListElement.innerHTML += " " + reptileElements[i]["id"];
    }
}

function listAnimalSpeciesByClassA() {
    let animalClasses = ["mammal", "reptile"];
    let animalClassListIds = ["m-list", "r-list"];
    
    for (let c = 0; c < animalClasses.length; ++c) {
	let elements = document.getElementsByClassName(animalClasses[c]);
	let listElement = document.getElementById(animalClassListIds[c]);
	for (let i = 0; i < elements.length; ++i) {
	    listElement.innerHTML += " " + elements[i]["id"];
	}
    }
}

// Exercise 4 EX04
function listButtonNames() {
    let buttonH4s = document.querySelectorAll("button > h4");
    let listContents = "";
    
    for (let i = 0; i < buttonH4s.length; ++i) {
	listContents += "<li>" + buttonH4s[i].innerHTML + "</li>";
    }

    document.querySelector("#EX04 ul").innerHTML = listContents;
}
