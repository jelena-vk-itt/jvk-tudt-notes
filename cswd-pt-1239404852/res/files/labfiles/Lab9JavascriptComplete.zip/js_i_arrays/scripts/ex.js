
var people = ["Anne", "Ben", "Chris", "Don", "Emma", "Fran", "George"];
var tcArray = ["tea", "coffee", "tea", "coffee", "coffee", "coffee", "tea"];

function makeTCOrderList() {
    let ulContents = "";

    for (let i = 0; i < people.length; ++i) {
	ulContents += "<li>" + people[i] + " would like " + tcArray[i] + ".</li>";
    }

    document.getElementById("tcList").innerHTML = ulContents;
}



function makeTCOrderListFromInputs() {
    let ulContents = "";
    let names = document.getElementById("names-input").value.split(" ");
    let tcArr = document.getElementById("tc-input").value.split("");

    for (let i = 0; i < names.length; ++i) {
	ulContents += "<li>" + names[i] + " would like ";
	if (tcArr[i] == 'T') {
	    ulContents += "tea";
	} else {
	    ulContents += "coffee";
	}
	ulContents += ".</li>";
    }

    document.getElementById("tcList2").innerHTML = ulContents;
}
