function toUpperAndDisplayN(number) {

    let inputId = "input" + number;
    let outputId = "upperBox" + (number + 1);
    if (number == 4) {
	outputId = "upperBox" + 1;
    }

    let value = document.getElementById(inputId).value;
    let upperValue = value.toUpperCase();
    if (upperValue == "") {
	document.getElementById(outputId).innerHTML = "&nbsp;"
    } else {
	document.getElementById(outputId).innerHTML = upperValue;
    }
}

