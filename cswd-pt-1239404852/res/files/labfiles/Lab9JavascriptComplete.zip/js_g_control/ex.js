function makeLetterList() {

    var word = document.getElementById("wordInput").value;

    var ulElementContentString = "";
    for (var i = 0; i < word.length; ++i) {
	var liElementString = "<li>" + word.charAt(i) + "</li>";
	ulElementContentString += liElementString;
    }

    document.getElementById("letterList").innerHTML = ulElementContentString;
}


function makeTable() {

    var word = document.getElementById("wordInput2").value;

    var tableContentString = "";
    for (let i = 0; i < word.length; ++i) {
	tableContentString += "<tr>";
	let tableDataCellElementString = "<td>" + word[i] + "</td>";
	for (var j = 0; j < 5; ++j) {
	    tableContentString +=tableDataCellElementString;
	}
	tableContentString += "</tr>";
    }

    document.getElementById("letterTable").innerHTML = tableContentString;
}

function logRandomNumbers() {
    let r = 10;
    while(r != 0) {
	r = Math.floor(Math.random() * 10);
	console.log(r);
    }
}
