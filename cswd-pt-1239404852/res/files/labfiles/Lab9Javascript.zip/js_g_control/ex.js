function makeLetterList() {
}


function makeTable() {
}

