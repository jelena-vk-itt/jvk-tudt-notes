function toUpperAndDisplayN(number) {

    let inputId = /* ADD CODE HERE TO CREATE THE INPUT ID */;
    let outputId = /* ADD CODE HERE TO CREATE THE INPUT ID */;

    let value = document.getElementById(inputId).value;
    let upperValue = value.toUpperCase();
    if (upperValue == "") {
	document.getElementById(outputId).innerHTML = "&nbsp;"
    } else {
	document.getElementById(outputId).innerHTML = upperValue;
    }
}

