from product import Product

class Shop:
    def __init__(self, name):
        self.name = name
        self._products = []

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name):
        self._name = name

    def add_product(self, name, stock):
        i = self._get_index_of_product(name, warn=False)
        if not i is None:
            print(f'Error: A product with name {name} already exists')
            return
        self._products.append(Product(name, stock))
        
    def remove_product(self, name):
        i = self._get_index_of_product(name)
        if i:
            self._products.pop(i)
        
    def restock(self, name, quantity):
        i = self._get_index_of_product(name)
        if not i is None:
            stock = self._products[i].stock
            self._products[i].stock = stock + quantity

    def sell(self, name, quantity):
        self.restock(name, quantity * -1)

    def print_product_list(self, low_stock_only = False):
        if low_stock_only:
            heading = "LOW ON STOCK"
            products = [p for p in self._products if p.stock_is_low()]
        else:
            heading = "ALL PRODUCTS"
            products = self._products

        Shop._print_header(heading)
        for p in products:
            Shop._print_product(p.name, p.stock)
        Shop._print_footer()

    # helper functions
    _SEP_LINE = "-" * 22
    _LINE_FORMAT = "{0: <12}{1: <10}"

    @staticmethod
    def _print_header(heading):
        print(Shop._SEP_LINE)
        print(heading.center(len(Shop._SEP_LINE), " "))
        print(Shop._SEP_LINE)
        print(Shop._LINE_FORMAT.format("Name", "Stock"))
        print(Shop._SEP_LINE)

    @staticmethod
    def _print_footer():
        print(Shop._SEP_LINE)

    @staticmethod
    def _print_product(name, stock):
        print(Shop._LINE_FORMAT.format(name, stock))

    def _get_index_of_product(self, name, warn=True):
        index = [i for i, p in enumerate(self._products) if p.name == name]
        if len(index) == 0:
            # warning should be issued only if asked for:
            if warn:
                print(f'Error: A product with name {name} was not found.')
            return None
        return index[0]

