class Product:
    
    _LOW_STOCK_MARK = 3
    
    def __init__(self, in_name, in_stock):
        self.name = in_name
        self.stock = in_stock

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, in_name):
        self._name = in_name

    @property
    def stock(self):
        return self._stock

    @stock.setter
    def stock(self, stock):
        self._stock = stock

    def stock_is_low(self):
        return self._stock <= Product._LOW_STOCK_MARK

    def get_department(self):
        return "General"

    def __str__(self):
        return f"Product name: {self.name}, department: {self.get_department()}, stock: {self.stock}"

class FoodProduct(Product):

    def __init__(self, n, s, ed):
        super().__init__(n, s)
        self.expiry_date = ed

    @property
    def expiry_date(self):
        return self._expiry_date

    @expiry_date.setter
    def expiry_date(self, ed):
        if not self._is_valid_date(ed):
            print(f"Date should be valid and in format 'dd/mm/yy', found {ed}. Setting to '01/01/00'.")
            self._expiry_date = '01/01/00'
        else:
            self._expiry_date = ed

    def get_department(self):
        return "Food"

    def __str__(self):
        return super().__str__() + f", expiry date: {self._expiry_date}"

    # helper method
    @staticmethod
    def _is_valid_date(date):

        # if not a string, not valid
        if not type(date) == str:
            return False

        # check length and slashes
        if len(date) != 8 or date[2] != "/" or date[5] != "/":
            return False

        # split by '/' and join with no spaces to get
        # what should be digits only
        if not ''.join(date.split(sep='/')).isdigit():
            return False

        # get day, month and year variables
        day, month, year = int(date[0:2]), int(date[3:5]), int(date[6:8])

        # check month
        if not 1 <= month <= 12:
            return False

        # check the day (must not be less than 1 or greater than
        # the number of days in the month
        if day < 1 or day > [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1]:
            return False

        # check for 29th of February in non-leap year
        leap = year != 0 and year % 4 == 0
        if not leap and month == 2 and day == 29:
            return False

        # all checks for problems passed
        return True


class ClothingProduct(Product):

    def __init__(self, n, s, season):
        super().__init__(n, s)
        self.season = season

    @property
    def season(self):
        return self._season

    @season.setter
    def season(self, season):
        if season not in ["spring", "summer", "autumn", "winter"]:
            print(f"Invalid season {season}. Setting to 'spring'.")
            self._season = 'spring'
        else:
            self._season = season

    def get_department(self):
        return "Clothing"

    def __str__(self):
        return super().__str__() + f", season: {self._season}"

