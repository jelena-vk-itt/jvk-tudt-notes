from product import Product

class ClothingProduct(Product):

    def __init__(self, name, stock, season):
        super().__init__(name, stock)
        if self.__check_season_value(season):
            self._season = season
        else:
            self._season = 'spring'

    def get_department(self):
        return "Clothing"

    @property
    def season(self):
        return self._season

    @season.setter
    def season(self, season):
        if self.__check_season_value(season):
            self._season = season

    def __check_season_value(self, season):
        if not season in ['spring', 'summer', 'autumn', 'winter']:
            print(f"Season must be 'spring', 'summer', 'autumn' or 'winter' but value '{season}' was supplied. ", end='')
            # checking if attribute already exists to set it to some default
            # otherwise leave untouched
            if hasattr(self, '_season'):
                print("Not modifying.")
            else:
                print("Setting to 'spring'.")
            return False
        return True

    def __str__(self):
        return super().__str__() + f", season: {self.season}"



