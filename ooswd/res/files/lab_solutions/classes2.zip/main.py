from product import Product, FoodProduct, ClothingProduct
from shop import Shop

print("================ TESTING Product ================")

print()
print("Creating product object with name Milk and stock 5...")
p = Product("Milk", 5)
print("done.")

print()
print("Getting and printing the name from the product object:")
print(p.name)
print("done.")

print()
print("Getting and printing the stock from the product object:")
print(p.stock)
print("done.")

print()
print("Setting the product name to Cream and printing the name from the product object:")
p.name = "Cream"
print(p.name)
print("done.")

print()
print("Setting the product stock to 10 and printing the stock from the product object:")
p.stock = 10
print(p.stock)
print("done.")

print()
print("Checking stock and printing result:")
print("Stock is low:", p.stock_is_low())
print("done.")

print()
print("Setting the stock to 2, then checking stock and printing result:")
p.stock = 2
print("Stock is low:", p.stock_is_low())
print("done.")

print()
print("Printing the product:")
print(p)
print("done.")

print()
print("Creating a food product and printing it:")
bread = FoodProduct("Bread", 5, "15/11/26")
print(bread)
print("done.")

print()
print("Creating a food product with 29th of February in expiry and printing it:")
beans = FoodProduct("Beans", 5, "29/02/28")
print(beans)
print("done.")

print()
print("Creating a food products with various invalid expiry dates and printing them:")
yoghurt = FoodProduct("yogurt", 5, "11/21/24")
print(yoghurt)
print("-")
yoghurt = FoodProduct("yogurt", 5, "29/02/23")
print(yoghurt)
print("-")
yoghurt = FoodProduct("yogurt", 5, "2/2/23")
print(yoghurt)
print("-")
yoghurt = FoodProduct("yogurt", 5, "25-12-24")
print(yoghurt)
print("-")
yoghurt = FoodProduct("yogurt", 5, "ab/cd/ef")
print(yoghurt)
print("-")
yoghurt = FoodProduct("yogurt", 5, 251226)
print(yoghurt)
print("done.")

print()
print("Creating a clothing product and printing it:")
dress = ClothingProduct("Dress", 3, "autumn")
print(dress)
print("done.")

print()
print("Creating a clothing product with invalid season and printing it:")
coat = ClothingProduct("Coat", 4, "midwinter")
print(coat)
print("done.")


print()
print()
print("================ TESTING Shop ================")

print()
print("Creating shop...")
s = Shop("Corner shop")
print("done.")

print()
print("Printing product list:")
s.print_product_list()
print("done.")

print()
print("Adding product cake and printing the product list:")
s.add_product("cake", 1)
s.print_product_list()
print("done.")

print()
print("Adding a few more products and printing the product list:")
s.add_product("milk", 3)
s.add_product("bread", 5)
s.add_product("lettuce", 6)
s.add_product("apples", 7)
s.print_product_list()
print("done.")

print()
print("Trying to add cake again and printing the product list:")
s.add_product("cake", 1)
s.print_product_list()
print("done.")

print()
print("Removing product bread and printing the product list:")
s.remove_product("bread")
s.print_product_list()
print("done.")

print()
print("Removing product lobster and printing the product list:")
s.remove_product("lobster")
s.print_product_list()
print("done.")

print()
print("Printing the list of products low on stock:")
s.print_product_list(low_stock_only=True)
print("done.")

print()
print("Restocking milk and cake with 8 each and printing product list, then low on stock list:")
s.restock("milk", 8)
s.restock("cake", 8)
s.print_product_list()
print()
s.print_product_list(low_stock_only=True)
print("done.")

print()
print("Trying to restock lobster with quantity 2 and printing the product list:")
s.restock("lobster", 2)
s.print_product_list()
print("done.")

print()
print("Selling 7 apples and 5 lettuce, then printing full and low-on-stock lists:")
s.sell("apples", 7)
s.sell("lettuce", 5)
s.print_product_list()
print()
s.print_product_list(low_stock_only=True)
print("done.")


