from product import Product
from foodproduct import FoodProduct
from clothingproduct import ClothingProduct
from shop import Shop

def test_product():
    print("================ TESTING Product ================")

    print()
    print("Creating product object with name Milk and stock 5...")
    p = Product("Milk", 5)
    print("done.")

    print()
    print("Getting and printing the name from the product object:")
    print(p.name)
    print("done.")

    print()
    print("Getting and printing the stock from the product object:")
    print(p.stock)
    print("done.")

    print()
    print("Setting the product name to UHT Milk and printing the name from the product object:")
    p.name = "UHT Milk"
    print(p.name)
    print("done.")

    print()
    print("Setting the product stock to 10 and printing the stock from the product object:")
    p.stock = 10
    print(p.stock)
    print("done.")

    print()
    print("Checking stock and printing result:")
    print("Stock is low:", p.stock_is_low())
    print("done.")

    print()
    print("Setting the stock to 2, then checking stock and printing result:")
    p.stock = 2
    print("Stock is low:", p.stock_is_low())
    print("done.")

    # ---------------- FOOD ------------------
    print()
    print("Creating food product with Bread, 11, 17/11/25...")
    f = FoodProduct("Bread", 11, "17/11/25")
    print("done.")

    print()
    print("Getting and printing out food product variables and if stock is low:")
    print(f.name)
    print(f.stock)
    print(f.exp_date)
    print("Stock is low:", f.stock_is_low())
    print("done.")

    print()
    print("Setting food product variables to Rye Bread, 2, 20/11/25, \
           \nthen getting and printing all, including if low in stock:")
    f.name = "Rye Bread"
    f.stock = 2
    f.exp_date = "20/11/25"
    print(f.name)
    print(f.stock)
    print(f.exp_date)
    print("Stock is low:", f.stock_is_low())
    print("done.")


    print()
    print("Setting food product stock to 7 and printing out if stock is low:")
    f.stock = 7
    f.exp_date = "20/11/25"
    print(f.name)
    print(f.stock)
    print(f.exp_date)
    print("Stock is low:", f.stock_is_low())
    print("done.")

    # ---------------- CLOTHING ------------------
    print()
    print("Creating clothing product with Dress, 4, summer...")
    c = ClothingProduct("Dress", 4, "summer")
    print("done.")

    print()
    print("Getting and printing out clothing product variables and if stock low:")
    print(c.name)
    print(c.stock)
    print(c.season)
    print("Stock is low:", c.stock_is_low())
    print("done.")

    print()
    print("Setting clothing product variables to Pinafore, 2, winter, \
            \nthen getting and printing all variables and whether stock is low:")
    c.name = "Pinafore"
    c.stock = 2
    c.season = "winter"
    print(c.name)
    print(c.stock)
    print(c.season)
    print("Stock is low:", c.stock_is_low())
    print("done.")

    print()
    print("Setting clothing product season to 'high', then getting and printing season:")
    c.season = 'high'
    print(c.season)
    print("done.")

    print()
    print("Creating other clothing product with Jacket, 6, low...")
    ci = ClothingProduct("Jacket", 6, "low")
    print("done.")

    print()
    print("Getting and printing out all other clothing product variables and if stock low:")
    print(ci.name)
    print(ci.stock)
    print(ci.season)
    print("Stock is low:", ci.stock_is_low())
    print("done.")

    print()
    print("Printing one of each Product, FoodProduct and ClothingProduct with the print function:")
    print(p)
    print(f)
    print(c)
    print("done.")

    print()
    print("Creating and printing a list of four products:")
    products = [
        FoodProduct('Apples', 5, '22/12/25'),
        FoodProduct('Tea', 4, '01/01/27'),
        ClothingProduct('Raincoat', 1, 'autumn'),
        ClothingProduct('Jumper', 10, 'winter')
    ]
    for p in products:
        print(p)
    print("done.")

    print()
    print("Comparing Tea and Jumper:")
    print("Tea is less than Jumper:", products[1] < products[3])
    print("done.")

    print()
    print("Sorting then printing the product list from above:")
    sorted_products = sorted(products)
    for p in sorted_products:
        print(p)
    print("done.")



def test_shop():
    print("================ TESTING Shop ================")

    print()
    print("Creating shop...")
s = Shop("Corner shop")
    print("done.")

    print()
    print("Printing product list:")
    s.print_product_list()
    print("done.")

    print()
    print("Adding product cake and printing the product list:")
    s.add_product("cake", 1)
    s.print_product_list()
    print("done.")

    print()
    print("Adding a few more products and printing the product list:")
    s.add_product("milk", 3)
    s.add_product("bread", 5)
    s.add_product("lettuce", 6)
    s.add_product("apples", 7)
    s.print_product_list()
    print("done.")

    print()
    print("Trying to add cake again and printing the product list:")
    s.add_product("cake", 1)
    s.print_product_list()
    print("done.")

    print()
    print("Removing product bread and printing the product list:")
    s.remove_product("bread")
    s.print_product_list()
    print("done.")

    print()
    print("Removing product lobster and printing the product list:")
    s.remove_product("lobster")
    s.print_product_list()
    print("done.")

    print()
    print("Printing the list of products low on stock:")
    s.print_product_list(low_stock_only=True)
    print("done.")

    print()
    print("Restocking milk and cake with 8 each and printing product list, then low on stock list:")
    s.restock("milk", 8)
    s.restock("cake", 8)
    s.print_product_list()
    print()
    s.print_product_list(low_stock_only=True)
    print("done.")

    print()
    print("Trying to restock lobster with quantity 2 and printing the product list:")
    s.restock("lobster", 2)
    s.print_product_list()
    print("done.")

    print()
    print("Selling 7 apples and 5 lettuces, then printing full and low-on-stock lists:")
    s.sell("apples", 7)
    s.sell("lettuce", 5)
    s.print_product_list()
    print()
    s.print_product_list(low_stock_only=True)
    print("done.")

test_product()
print("\n")
#test_shop()
