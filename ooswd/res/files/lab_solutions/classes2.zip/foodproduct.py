from product import Product

class FoodProduct(Product):

    def __init__(self, name, stock, exp_date):
        super().__init__(name, stock)
        self._exp_date = exp_date

    def get_department(self):
        return "Groceries"

    @property
    def exp_date(self):
        return self._exp_date

    @exp_date.setter
    def exp_date(self, exp_date):
        self._exp_date = exp_date

    def __str__(self):
        return super().__str__() + f", expiry date: {self.exp_date}"