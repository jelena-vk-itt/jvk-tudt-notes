import csv
from enum import StrEnum

ADMIN_MODE = True

##########################################################################################
####### DICTIONARY CLASS
##########################################################################################
class Dictionary:
    """
    A dictionary of words that can be looked up for their definitions
    """
    def __init__(self, filename):
        """
        Constructor
        :param filename: str
            The name of the file containing comma-separated key-value pairs, one per row
        """
        self.__d = dict({})
        with open(filename, "r") as dataFile:
            csv_reader = csv.reader(dataFile, delimiter=",")
            for row in csv_reader:
                self.__d[row[0]] = row[1]

    def apply_to_entries(self, func):
        """
        Applies func to all the entries in the dictionary.

        :param func: Callable[[str, str], None]
            The function to be applied to each entry, expecting the word and definition as string parameters.
        :return: None
        """
        for k, v in self.__d.items():
            func(k, v)

    def lookup_word(self, word):
        """
        Looks up a word, returning its definition.
        :param word: str
            The word to be looked up
        :return: str
            The word's definition
        """
        return self.__d.get(word)

    def add_words(self, *words_and_defs, force=False):
        """
        Adds any number of words, with their definitions, to the dictionary.
        :param words_and_defs: str
            The words and definitions, specified in the following order:
            first word, first definition, second word, second definition, etc.
        :param force: bool
            Specifies if definitions of words that are already in the dictionary should be overwritten
        :return: dict[str, bool]
            A dictionary mapping words to boolean indicators of whether the words were added or not.
            A word is not added if it already exists in the dictionary and force==False.
        """
        added = dict()
        for wnd in [(words_and_defs[i], words_and_defs[i+1]) for i in range(0, len(words_and_defs) - 1, 2)]:
            if not force and self.__d.get(wnd[0]):
                added[wnd[0]] = False
            else:
                self.__d[wnd[0]] = wnd[1]
                added[wnd[0]] = True
        return added

    def delete_word(self, word):
        """
        Deletes a specified word from the dictionary.
        :param word: str
        :return: bool
            An indicator of whether the word was in the dictionary and removed, or not
        """
        return False if self.__d.pop(word, None) is None else True


##########################################################################################
####### DICTIONARY UI CLASS
##########################################################################################
class DictionaryUI:
    class OPTION(StrEnum):
        LOOKUP = "1"
        ADD = "2"
        DELETE = "3"
        EXIT = "4"
        PRINT_ALL = "0"

    @staticmethod
    def __print_table_row(d1, d2):
        """
        Prints a table row with information for one dictionary entry
        :param d1: str
            The word
        :param d2: str
            The definition
        :return: None
        """
        print("{: <12} {}".format(d1, d2))

    @staticmethod
    def __join_words(lw):
        """
        Joins the words in the list with orthographically correct separators
        i.e. commas except the last two items, which are separated with an 'and'.
        :param lw: list[str]
            The list of words
        :return: str
            The joined words
        """
        return "".join([s.replace(",", " and") if i == 1 else s
                        for i, s in enumerate(", ".join(lw).rpartition(", "))])

    def __init__(self, d):
        """
        Constructor - creates a UI object for a Dictionary object
        :param d: dict[str, str]
        """
        self.__dct = d

    def run(self):
        """
        Displays the main menu, then processes the option entered by the user, repeatedly in a loop
        :return: None
        """
        finished = False
        while not finished:
            # display the menu
            print("=================================")
            print("=== Welcome to the dictionary ===")
            print("=================================")
            print()
            print("What would you like to do?")
            print("--------------------------")
            print(self.OPTION.LOOKUP + " Look up a word")
            print(self.OPTION.ADD + " Add words to the dictionary")
            print(self.OPTION.DELETE + " Delete a word from the dictionary")
            print(self.OPTION.EXIT + " Exit")
            if ADMIN_MODE:
                print(self.OPTION.PRINT_ALL + " Print entire dictionary")

            # read and process the option
            print("--------------------------")
            opt = input("Please enter an option code: ")
            print("--------------------------")
            if opt == self.OPTION.LOOKUP:
                word = input("\nPlease enter the word you would like to look up: ")
                definition = self.__dct.lookup_word(word)
                if not definition:
                    print(f"\nThe word {word} was not found in the dictionary.")
                else:
                    print(f"\nThe following definition was found for {word}:\n")
                    self.__print_table_row(word, definition)
                print()

            elif opt == self.OPTION.ADD:
                add_args = []
                word = input("\nPlease enter the first word you would like to add (empty string to cancel): ")
                while word:
                    add_args.append(word)
                    add_args.append(input("\nPlease enter a definition for the word: "))
                    word = input("\nPlease enter the next word you would like to add (empty string to stop): ")
                add_result = self.__dct.add_words(*add_args)
                not_added = [k for k, v in add_result.items() if not v]
                if len(not_added):
                    if len(not_added) == 1:
                        force = input(f"\nThe word {self.__join_words(not_added)} has "
                                      "not been added as it is already in the dictionary."
                                      " Would you like to overwrite it [y/n]? ")
                    else:
                        force = input(f"\nThe words {self.__join_words(not_added)} have " 
                                      "not been added as they are already in the dictionary."
                                      " Would you like to overwrite them [y/n]? ")
                    if force == 'y':
                        not_added_idcs = [i for i in range(0, len(add_args) - 1, 2) if add_args[i] in not_added]
                        self.__dct.add_words(*sum([[add_args[i], add_args[i + 1]] for i in not_added_idcs], []),
                                             force=True)

            elif opt == self.OPTION.DELETE:
                word = input("\nPlease enter the word you would like delete: ")
                deleted = self.__dct.delete_word(word)
                if deleted:
                    print(f"\nThe word {word} has been deleted from the dictionary.\n")
                else:
                    print(f"\nThe word {word} was not found in the dictionary.\n")

            elif opt == self.OPTION.EXIT:
                finished = True

            elif ADMIN_MODE and opt == self.OPTION.PRINT_ALL:
                print()
                DictionaryUI.__print_table_row("WORD", "DEFINITION")
                print("---------------------------------")
                self.__dct.apply_to_entries(DictionaryUI.__print_table_row)
                print()

            else:
                print("That is not a valid option.\n")

##########################################################################################
####### PROGRAM RUN CODE
##########################################################################################
DictionaryUI(Dictionary("data.csv")).run()

##########################################################################################
####### DICTIONARY TESTING FUNCTIONS (NOT USED IN THE FINAL VERSION OF THIS FILE)
##########################################################################################
def print_test_header(desc):
    print("\n====================================================")
    print(f"=== TEST ===> {desc} ")
    print("====================================================")

def print_table_row(d1, d2):
    print("{: <12} {}".format(d1, d2))

def test_dictionary():
    def print_dictionary(dictionary: Dictionary):
        print()
        print_table_row("Word", "Definition")
        print("-------------------------------------------------")
        dictionary.apply_to_entries(print_table_row)

    d = Dictionary("data.csv")

    print_test_header("print entire dictionary")
    print_dictionary(d)

    print_test_header("look up word 'apple'")
    print("Definition: ", d.lookup_word("apple"))

    print_test_header("add words 'apple' and 'fish' to the dictionary, not using the 'force' flag")
    print("Output: ", d.add_words("apple", "a tasty fruit",
                                                  "fish", "a class of vertebrates that live in water"))
    print_dictionary(d)

    print_test_header("add word 'apple', using the 'force' flag")
    print("Output: ", d.add_words("apple", "a tasty fruit",
                                                  force=True))
    print_dictionary(d)

    print_test_header("delete word 'apple'")
    print("Output: ", d.delete_word("apple"))
    print_dictionary(d)


    print_test_header("delete word 'zzzzz'")
    print("Output: ", d.delete_word("zzzzz"))
    print_dictionary(d)

