class Product:
    
    lowStockMark = 3
    
    def __init__(self, name, stock):
        self._name = name
        self._stock = stock

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    def get_stock(self):
        return self._stock

    def set_stock(self, stock):
        self._stock = stock

    def stock_is_low(self):
        return self._stock <= Product.lowStockMark
