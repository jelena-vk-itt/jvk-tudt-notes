from product import Product

class Shop:
    def __init__(self, name):
        self._name = name
        self._products = []

    def add_product(self, name, stock):
        i = self.get_index_of_product(name, warn=False)
        if not i is None:
            print(f'Error: A product with name {name} already exists')
            return
        self._products.append(Product(name, stock))
        
    def remove_product(self, name):
        i = self.get_index_of_product(name)
        if i:
            self._products.pop(i)
        
    def restock(self, name, quantity):
        i = self.get_index_of_product(name)
        if not i is None:
            stock = self._products[i].get_stock()
            self._products[i].set_stock(stock + quantity)

    def sell(self, name, quantity):
        self.restock(name, quantity * -1)

    def print_product_list(self, low_stock_only = False):
        if low_stock_only:
            heading = "LOW ON STOCK"
            products = [p for p in self._products if p.stock_is_low()]
        else:
            heading = "ALL PRODUCTS"
            products = self._products

        self.print_header(heading)
        for p in products:
            self.print_product(p.get_name(), p.get_stock())
        self.print_footer()

    # helper functions
    SEP_LINE = "-" * 22
    LINE_FORMAT = "{0: <12}{1: <10}"
    def print_header(self, heading):
        print(Shop.SEP_LINE)
        print(heading.center(len(Shop.SEP_LINE), " "))
        print(Shop.SEP_LINE)
        print(Shop.LINE_FORMAT.format("Name", "Stock"))
        print(Shop.SEP_LINE)

    def print_footer(self):
        print(Shop.SEP_LINE)

    def print_product(self, name, stock):
        print(Shop.LINE_FORMAT.format(name, stock))

    def get_index_of_product(self, name, warn=True):
        index = [i for i, p in enumerate(self._products) if p.get_name() == name]
        if len(index) == 0:
            # warning should be issued only if asked for:
            if warn:
                print(f'Error: A product with name {name} was not found.')
            return None
        return index[0]

