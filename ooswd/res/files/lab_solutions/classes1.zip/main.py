from product import Product
from shop import Shop

print("================ TESTING Product ================")

print()
print("Creating product object with name Milk and stock 5...")
p = Product("Milk", 5)
print("done.")

print()
print("Getting and printing the name from the product object:")
print(p.get_name())
print("done.")

print()
print("Getting and printing the stock from the product object:")
print(p.get_stock())
print("done.")

print()
print("Setting the product name to Cream and printing the name from the product object:")
p.set_name("Cream")
print(p.get_name())
print("done.")

print()
print("Setting the product stock to 10 and printing the stock from the product object:")
p.set_stock(10)
print(p.get_stock())
print("done.")

print()
print("Checking stock and printing result:")
print("Stock is low:", p.stock_is_low())
print("done.")

print()
print("Setting the stock to 2, then checking stock and printing result:")
p.set_stock(2)
print("Stock is low:", p.stock_is_low())
print("done.")

print()
print()
print("================ TESTING Shop ================")

print()
print("Creating shop...")
s = Shop("Corner shop")
print("done.")

print()
print("Printing product list:")
s.print_product_list()
print("done.")

print()
print("Adding product cake and printing the product list:")
s.add_product("cake", 1)
s.print_product_list()
print("done.")

print()
print("Adding a few more products and printing the product list:")
s.add_product("milk", 3)
s.add_product("bread", 5)
s.add_product("lettuce", 6)
s.add_product("apples", 7)
s.print_product_list()
print("done.")

print()
print("Trying to add cake again and printing the product list:")
s.add_product("cake", 1)
s.print_product_list()
print("done.")

print()
print("Removing product bread and printing the product list:")
s.remove_product("bread")
s.print_product_list()
print("done.")

print()
print("Removing product lobster and printing the product list:")
s.remove_product("lobster")
s.print_product_list()
print("done.")

print()
print("Printing the list of products low on stock:")
s.print_product_list(low_stock_only=True)
print("done.")

print()
print("Restocking milk and cake with 8 each and printing product list, then low on stock list:")
s.restock("milk", 8)
s.restock("cake", 8)
s.print_product_list()
print()
s.print_product_list(low_stock_only=True)
print("done.")

print()
print("Trying to restock lobster with quantity 2 and printing the product list:")
s.restock("lobster", 2)
s.print_product_list()
print("done.")

print()
print("Selling 7 apples and 5 lettuce, then printing full and low-on-stock lists:")
s.sell("apples", 7)
s.sell("lettuce", 5)
s.print_product_list()
print()
s.print_product_list(low_stock_only=True)
print("done.")


