from product import Product
from shop import Shop


print("================ TESTING error handling in Product ================")

print()
print("Trying to create a Product with empty string as name:")
try:
    p = Product('', 3)
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to create a Product with a number as name:")
try:
    p = Product(0.4, 3)
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to create Product (Milk, -3):")
try:
    p = Product('Milk', -3)
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to create Product (Milk, abcd):")
try:
    p = Product('Milk', 'abcd')
except Exception as e:
    print(f"ERROR: {e}")
print("done.")


print("================ TESTING error handling in Shop ================")
# declare the shop variable that will be used in all try-except statements
s = None

print()
print("Trying to create a Shop with empty string as name:")
try:
    s = Shop('')
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to create a Shop with a number as name:")
try:
    s = Shop(3)
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Creating shop called 'Corner Shop', \nadding products (Newspaper, 10), (Ice cream, 20) and \nprinting the product list:")
try:
    s = Shop('Corner Shop')
    s.add_product('Newspaper', 10)
    s.add_product('Ice cream', 20)
    s.print_product_list()
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to add product (Newspaper, 4) to the shop:")
try:
    s.add_product('Newspaper', 4)
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to remove product Milk from the shop:")
try:
    s.remove_product('Milk')
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to restock product Milk with quantity 10:")
try:
    s.restock('Bread', 10)
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to sell 2 of product Apples:")
try:
    s.sell('Apples', 2)
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Printing the product list (to check that nothing was modified:")
try:
    s.print_product_list()
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to restock Newspaper with -1:")
try:
    s.restock('Newspaper', -1)
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to restock Newspaper with 'abc':")
try:
    s.restock('Newspaper', 'abc')
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to sell -1 of Newspaper:")
try:
    s.sell('Newspaper', -1)
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to sell 'abc' of Newspaper:")
try:
    s.sell('Newspaper', 'abc')
except Exception as e:
    print(f"ERROR: {e}")
print("done.")

print()
print("Trying to sell 30 of Newspaper:")
try:
    s.sell('Newspaper', 'abc')
except Exception as e:
    print(f"ERROR: {e}")
print("done.")
