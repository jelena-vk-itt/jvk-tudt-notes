from product import Product

class Shop:
    def __init__(self, name):
        # (c)
        if type(name) != str:
            raise TypeError("Shop name must be a non-empty string.")
        if name == '':
            raise ValueError("Shop name must be a non-empty string.")
        self._name = name
        self._products = []

    def add_product(self, name, stock):
        # (d)
        self._check_product_not_in_list(name)
        self._products.append(Product(name, stock))
        
    def remove_product(self, name):
        i = self._get_index_of_product(name)
        self._products.pop(i)
        
    def restock(self, name, quantity):
        i = self._get_index_of_product(name)
        stock = self._products[i].get_stock()
        # (f)
        if type(quantity) != int:
            raise TypeError("Restock quantity must be a non-negative integer.")
        if quantity < 0:
            raise ValueError("Restock quantity must be a non-negative integer.")
        self._products[i].set_stock(stock + quantity)

    def sell(self, name, quantity):
        i = self._get_index_of_product(name)
        stock = self._products[i].get_stock()
        # (g)
        if type(quantity) != int:
            raise TypeError("Sell quantity must a non-negative integer not greater than the stock.")
        if quantity < 0 or quantity > stock:
            raise ValueError("Sell quantity must a non-negative integer not greater than the stock.")
        self._products[i].set_stock(stock - quantity)


    def print_product_list(self, low_stock_only = False):
        if low_stock_only:
            heading = "LOW ON STOCK"
            products = [p for p in self._products if p.stock_is_low()]
        else:
            heading = "ALL PRODUCTS"
            products = self._products

        self.print_header(heading)
        for p in products:
            self.print_product(p.get_name(), p.get_stock())
        self.print_footer()

    # helper functions
    SEP_LINE = "-" * 22
    LINE_FORMAT = "{0: <12}{1: <10}"

    def print_header(self, heading):
        print(Shop.SEP_LINE)
        print(heading.center(len(Shop.SEP_LINE), " "))
        print(Shop.SEP_LINE)
        print(Shop.LINE_FORMAT.format("Name", "Stock"))
        print(Shop.SEP_LINE)

    def print_footer(self):
        print(Shop.SEP_LINE)

    def print_product(self, name, stock):
        print(Shop.LINE_FORMAT.format(name, stock))

    # (e)
    def _get_index_of_product(self, name):
        index = [i for i, p in enumerate(self._products) if p.get_name() == name]
        if len(index) == 0:
            raise LookupError(f'A product with name {name} was not found.')
        return index[0]

    def _check_product_not_in_list(self, name):
        found = [p for p in self._products if p.get_name() == name]
        if len(found) > 0:
            raise ValueError(f'Error: A product with name {name} already exists in the shop.')

