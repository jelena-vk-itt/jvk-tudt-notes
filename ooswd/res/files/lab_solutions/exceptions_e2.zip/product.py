class Product:
    
    lowStockMark = 3
    
    def __init__(self, name, stock):
        # (a) (b)
        Product._check_name_arg(name)
        Product._check_stock_arg(stock)
        self._name = name
        self._stock = stock

    def get_name(self):
        return self._name

    def set_name(self, name):
        # (a)
        Product._check_name_arg(name)
        self._name = name

    def get_stock(self):
        return self._stock

    def set_stock(self, stock):
        # (b)
        Product._check_stock_arg(stock)
        self._stock = stock

    def stock_is_low(self):
        return self._stock <= Product.lowStockMark
    
    @staticmethod
    def _check_name_arg(name):
        if type(name) != str:
            raise TypeError("Product name must be a non-empty string.")
        if name == '':
            raise ValueError("Product name must be a non-empty string.")

    @staticmethod
    def _check_stock_arg(stock):
        if type(stock) != int:
            raise TypeError("Stock must be a non-negative integer.")
        if stock < 0:
            raise ValueError("Stock must be a non-negative integer.")
