class Product:

    def __init__(self, n, d, s):

        # ASSIGNMENT 7: values checked and exceptions raised
        if n == "":
            raise ValueError("Product(name={}, description={}, stock={}): Name should be a non-empty string.".format(n, d, s))
        if type(s) != int or s < 0:
            raise ValueError("Product(name={}, description={}, stock={}): Stock should be a non-negative integer.".format(n, d, s))

        self.name = n
        self.description = d
        self.stock = s
