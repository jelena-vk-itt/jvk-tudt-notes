from product import Product

class Shop:
    template = "{0: <4}{1: <12}{2: <23}{3: <}"

    def __init__(self, data):
        self.products = list(map(lambda p: Product(*p), data))

    def add_product(self, name, desc, stock):
        # ASSIGNMENT 7: error handling added
        try:
            self.products.append(Product(name, desc, stock))
        except ValueError as ve:
            print("Invalid Product property:", ve)
            return False
        return True

    def remove_product(self, name):
        # ASSIGNMENT 7: error handling added
        try:
            index = list(map(lambda p: p.name, self.products)).index(name)
        except ValueError as ve:
            print("The product with name {} is not on the shop's list.".format(name))
            return False
        else:
            self.products.pop(index)
        return True

    def print_heading(self, listname):
        print("")
        print("=============== {} ===============".format(listname))
        print(self.template.format("ID", "Name", "Description", "Stock"))
        
    def print_product_list(self):
        self.print_heading("ALL PRODUCTS")
        for index, p in enumerate(self.products):
            print(self.template.format(index + 1, p.name, p.description, p.stock))
            
    def print_low_on_stock(self):
        self.print_heading("LOW ON STOCK")
        for index, p in enumerate(list(filter(lambda p: p.stock < 3, self.products))):
            print(self.template.format(index + 1, p.name, p.description, p.stock))
        

            

