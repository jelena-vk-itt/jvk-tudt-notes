from shop import Shop

DATA = [
    ["milk", "Fresh from the farm", 10],
    ["bread", "Fresh from the baker", 4],
    ["tea", "Box of 100 teabags", 1],
    ["eggs", "A dozen per box", 33],
    ["ice cream", "1l box, vanilla", 2]
]

s = Shop(DATA)

# test functionality
s.print_product_list()
s.print_low_on_stock()

print("\nAdding product cake...", end="")
s.add_product("cake", "Coffee and walnut", 1)
print("added.")

s.print_product_list()
s.print_low_on_stock()

print("\nRemoving product tea...", end="")
s.remove_product("tea")
print("removed.")

s.print_product_list()
s.print_low_on_stock()

# ADDED IN ASSIGNMENT 7:
# test error handling
print("\nAdding product without name...")
if s.add_product("", "", 1):
    print("added.")

print("\nAdding product pen with stock abc...")
if s.add_product("pen", "Multi-coloured", "abc"):
    print("added.")

print("\nRemoving product elephant...")
if s.remove_product("elephant"):
    print("removed.")






