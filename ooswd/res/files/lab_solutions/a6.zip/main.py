from datetime import datetime, timedelta
from product import Product
from product import FoodProduct
from shop import Shop

def test_heading(text):
    print("\n===========> TESTING: {}".format(text))


test_heading("Product constructor and print method")
towel = Product("towel", 1, 4)
towel.print()

test_heading("Product get_name method")
print("name: ", towel.get_name())

test_heading("Product get_stock method")
print("towel stock: ", towel.get_stock())

test_heading("Product set_stock method (print it to check that it was set to 7)")
towel.set_stock(7)
towel.print()

test_heading("Product is_perishable method")
print("towel is perishable: ", towel.is_perishable())

test_heading("Product stock_is_low method (test both true and false)")
bathMat = Product("bath mat", 3, 1)
print("towel stock is low: ", towel.stock_is_low())
print("bath mat stock is low: ", bathMat.stock_is_low())

test_heading("FoodProduct constructor")
milk = FoodProduct("milk", 1, 4, datetime(2024, 11, 11))
milk.print()

test_heading("FoodProduct is_perishable method (test both None and datetime value)")
tinOfBeans = FoodProduct("tin of beans", 3, 10, None)
tinOfBeans.print()
print("milk is perishable: ", milk.is_perishable())
print("tin of beans is perishable: ", tinOfBeans.is_perishable())

test_heading("FoodProduct is_out_of_date method (test both true and false)")
bread = FoodProduct("bread", 3, 11, datetime(2024, 10, 1))
bread.print()
print("milk is out of date: ", milk.is_out_of_date())
print("bread is out of date: ", bread.is_out_of_date())

test_heading("Shop constructor (test empty and with two products) and printing")
s1 = Shop("CornerShop")
s2 = Shop("SuperStore", [ towel, bathMat, milk, bread, tinOfBeans ])
s1.print_product_list()
s2.print_product_list()
s2.print_product_list("od")
s2.print_product_list("ls")
                      
test_heading("Shop add_product and remove_product")
s2.add_product(FoodProduct("broccoli", 2, 10, datetime.now() + timedelta(days=3)))
s2.print_product_list()
s2.remove_product("tin of beans")
s2.print_product_list()
s2.remove_product("caviar")

test_heading("Shop generate_messages")
s2.generate_messages()


test_heading("Shop restock (non-existent item 'caviar' and existing item 'bath mat')")
s2.restock("caviar", 10)
s2.restock("bath mat", 10)
s2.generate_messages()

test_heading("Shop sell (non-existent item 'caviar' and existing item 'milk')")
s2.sell("caviar", 30)
s2.sell("milk", 4)
s2.generate_messages()
