from datetime import datetime

class Product:
    def __init__(self, n, l, s):
        self.__name = n
        self.__lowStockMark = l
        self.__stock = s

    def print(self):
        print("Product name: " + self.__name
              + ", low stock mark: " + str(self.__lowStockMark)
              + ", stock: " + str(self.__stock))

    def get_name(self):
        return self.__name

    def get_stock(self):
        return(self.__stock)
        
    def set_stock(self, s):
        self.__stock = s

    def is_perishable(self):
        return False

    def stock_is_low(self):
        return self.__stock < self.__lowStockMark

    
class FoodProduct(Product):
    def __init__(self, n, l, s, u=None):
        super().__init__(n, l, s)
        self.__useByDate = u

    def is_perishable(self):
        return self.__useByDate != None

    def is_out_of_date(self):
        return datetime.now() > self.__useByDate
    
