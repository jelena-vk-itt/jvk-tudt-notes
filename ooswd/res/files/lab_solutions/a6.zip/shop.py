class Shop:
    def __init__(self, n, p=[]):
        self.__name = n
        self.__stockedProducts = p

        # checking for duplicates (not part of assignment)
        for i, p in enumerate(self.__stockedProducts):
            for r in self.__stockedProducts[i+1:]:
                if (p.get_name() == r.get_name()):
                    print(">>>>> ERROR Duplicate product name: " + p.get_name())

    def __get_low_in_stock_products(self):
        return [p for p in self.__stockedProducts if p.stock_is_low()]
        
    def __get_out_of_date_products(self):
        return [p for p in self.__stockedProducts if (p.is_perishable() and p.is_out_of_date())]

    # assume ideal user (no duplicates) for assignment
    def __get_product_by_name(self, name):
        products = [p for p in self.__stockedProducts if p.get_name() == name]
        if len(products) == 0:
            return None
        else:
            return products[0]
        

    def print_product_list(self, filter_str=""):
        if filter_str=="od":
            heading = "Out-of-date products"
            products_to_print = self.__get_out_of_date_products()

        elif filter_str=="ls":
            heading = "Low-in-stock products"
            products_to_print = self.__get_low_in_stock_products()

        else:
            heading = "All products"
            products_to_print = self.__stockedProducts


        print("----- {} in {} -----".format(heading, self.__name))
        if len(products_to_print) > 0:
            for p in products_to_print:
                p.print()
        else:
            print("None")

    def generate_messages(self):
        print("Low in stock: " + ", ".join(
            [p.get_name() for p in self.__get_low_in_stock_products()]))
        print("Out of date: " + ", ".join(
            [p.get_name() for p in self.__get_out_of_date_products()]))
        
            
    def add_product(self, p):
        self.__stockedProducts.append(p)


    def remove_product(self, name):
        product = self.__get_product_by_name(name)
        if product == None:
            print(">>>>> WARNING: Product not found.")
        else:
            self.__stockedProducts.remove(product)

    def restock(self, name, amount):
        product = self.__get_product_by_name(name)
        if product == None:
            print(">>>>> ERROR: Product '{}' not found.".format(name))
        else:
            product.set_stock(product.get_stock() + amount)
                
    def sell(self, name, amount):
        product = self.__get_product_by_name(name)
        if product == None:
            print(">>>>> ERROR: Product '{}' not found.".format(name))
        elif amount > product.get_stock():
            print(">>>>> ERROR: Not enough stock.")
        else:
            product.set_stock(product.get_stock() - amount)
