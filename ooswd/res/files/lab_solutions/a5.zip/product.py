class Product:

    def __init__(self, n, d, s):
        self.name = n
        self.description = d
        self.stock = s
