import csv
import math
import numpy as np
from random import random
from animal import Animal


class Zoo:
    TRANSFER_COUNT = 10

    def __init__(self):
        self.animals = []
        self.weightUnits = "kg"

    def __print_animals_at_indices__(self, indices, title):

        print("=======================================================")
        print(f" {title}")
        print("=======================================================\n")
        print("SPECIES                     NAME           AGE   WEIGHT")
        print("-------------------------------------------------------")
        for index in indices:
            animal = self.animals[index]
            print(f"{animal.species: <28}{animal.name: <15}{animal.age: <6}{animal.weight: <4}")
        
    def print_animals(self, count=-1):
        if count == -1 or count > len(self.animals):
            count = len(self.animals)
        print()
        self.__print_animals_at_indices__(range(count), "All animals")
        
    def add_animals(self, filename, header_row=True):
        try:
            with open(filename, "r") as f:
                csvRdr = csv.reader(f, delimiter=",")
                if header_row:
                    next(csvRdr)
                self.animals.extend([Animal(row[0], row[1], int(row[2]), int(row[3])) for row in csvRdr])
        except ValueError:
            print(f"An invalid value was found in file {filename}.")
        except IOError:
            print(f"An error occurred while reading the file {filename}.")        
        except FileNotFoundError:
            print(f"The file {filename} was not found.")

    def compile_transfer_list(self, filename):
        transfer_indices = []
        while len(transfer_indices) < Zoo.TRANSFER_COUNT:
            rand = math.floor(random() * len(self.animals))
            if not rand in transfer_indices:
                transfer_indices.append(rand)
        self.__print_animals_at_indices__(transfer_indices,
                                          f"Animals to be transferred (writing to {filename})")
        try:
            with open(filename, "w") as f:
                csvWrt = csv.writer(f, delimiter=",")
                csvWrt.writerows([self.animals[i].toList() for i in transfer_indices])
        except Exception as e:
            print(f"Error while writing to file: ", e)
        

    def convert_weights(self, units="kg"):
        conversion_factor = 1
        if units == "kg" and self.weightUnits == "lb":
            conversion_factor = 0.454
        elif units == "lb" and self.weightUnits == "kg":
            conversion_factor = 1/0.454

        if conversion_factor != 1:
            for a in self.animals:
                a.weight = round(a.weight * conversion_factor, 2)
            self.weightUnits = units
            
    def mean_weight(self):
        return np.array([a.weight for a in self.animals]).mean()
            
