from zoo import Zoo

def test_start(character, message, expected):
    print("\n\n\n\n\nooooooooooooooooooooooooooooooooooooooooooooooooooooooo")
    print(f"{(character + ' ')*11} TEST START {(character + ' ')*11}")
    print()
    print(message)
    print()
    print(f"Expected result: {expected}")
    print(".......................................................\n")

def test_end(character):
    print(f"\n{(character + ' ')*12} TEST END {(character + ' ')*11}")
    print("ooooooooooooooooooooooooooooooooooooooooooooooooooooooo\n\n")

test_start("1", "We create the zoo and print all the animals in the zoo", "empty zoo")
z = Zoo()
z.print_animals()
test_end("1")



test_start("2", "We add all the animals from the animals.csv file\nto the zoo, then print the first ten animals in the zoo.", "animals printed")
z.add_animals("animals.csv")
z.print_animals(10)
test_end("2")



test_start("3", "We create a transfer list and print it", "the transfer list is in transfer.csv")
z.compile_transfer_list("transfer.csv")
test_end("3")



test_start("4", "We convert from kgs to pounds and print the first 10 animals", "weights converted")
z.convert_weights("lb")
z.print_animals(10)
test_end("4")

test_start("5", "We convert back to kgs and print the first 10 animals", "weights converted")
z.convert_weights("kg")
z.print_animals(10)
test_end("5")

test_start("6", "We get the mean weight of the animals and print it", "mean weight printed")
mean_weight = z.mean_weight()
print(f"The mean weight of the animals in the zoo is {mean_weight}.")
test_end("6")
