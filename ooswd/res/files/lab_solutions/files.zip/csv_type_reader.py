import csv

class CsvTypeReader:
    def __init__(self):
        self._data = {}
        self._problems = {}

    def read_csv(self, file_name, type_list):
        expected_row_length = len(type_list)
        with open(file_name, "r") as file:
            csv_reader = csv.reader(file, delimiter=",")

            for num, row in enumerate(csv_reader, start=1):
                val_list = []
                if expected_row_length != len(row):
                    self._add_problem(num, f"{len(row)} elements instead of {expected_row_length}")
                else:
                    for ind, el in enumerate(row):
                        try:
                            val_list.append(type_list[ind](el))
                        except ValueError:
                            self._add_problem(num, f"Wrong type at position {ind + 1}: {self._typstr(type(el))} instead of {self._typstr(type_list[ind])}")

                if num not in self._problems:
                    self._data[num] = val_list

    def get_data(self):
        return self._data

    def get_problems(self):
        return self._problems

    def _add_problem(self, row_num, description):
        if row_num in self._problems:
            self._problems[row_num].append(description)
        else:
            self._problems[row_num] = [description]

    @staticmethod
    def _typstr(t):
        return str(t).strip("'<clas >").replace("tr", "str")
