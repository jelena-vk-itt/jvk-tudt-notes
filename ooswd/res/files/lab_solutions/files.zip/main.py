# implements requirement 6
from animal import Animal
from zoo import Zoo
from csv_type_reader import CsvTypeReader
from nice_print import dict_multiline_str

csv_reader = CsvTypeReader()
csv_reader.read_csv("MOCK_DATA.csv", [str, str, int, int])
print(f"Problems:\n{dict_multiline_str(csv_reader.get_problems(), "Line")}")

zoo = Zoo()
for key, value in csv_reader.get_data().items():
    try:
        zoo.add_animal(Animal(*value))
    except ValueError as ve:
        print(f"Error at line {key}, {ve}")

zoo.write_transfer_list("animals.csv")