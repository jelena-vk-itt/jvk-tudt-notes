from animal import Animal
from random import sample
import csv

class Zoo:
    TRANSFER_COUNT = 10

    def __init__(self):
        self._animals = []

    def add_animal(self, animal):
        if type(animal) != Animal:
            raise TypeError("Animal must be of type Animal.")
        self._animals.append(animal)

    def get_transfer_list(self):
        if len(self._animals) <= Zoo.TRANSFER_COUNT:
            return self._animals
        return sample(self._animals, k=Zoo.TRANSFER_COUNT)

    def write_transfer_list(self, file_name):
        with open(file_name, "w", newline="") as file:
            csv_writer = csv.writer(file, delimiter=",")
            for a in self.get_transfer_list():
                csv_writer.writerow([a.species, a.name, a.age, a.weight])

    # NOT WRITTEN DURING LAB DEMO BUT LATER
    # we need to be able to print the zoo to test our two
    # new methods
    def __str__(self):
        return "\n".join([str(a) for a in self._animals])

    def convert_weight(self, pounds_to_kilos):
        for a in self._animals:
            a.weight = int(round(a.weight * (0.454 if pounds_to_kilos else 2.2), 0))

    def mean_weight(self, species):
        # we use a list comprehension to filter in only
        # the given species and to create a list of
        # weights for those animals
        weights = [a.weight for a in self._animals if a.species == species]
        if len(weights):
            return sum(weights)/len(weights)
        # we return none if there aren't any animals of the
        # given species
        return None