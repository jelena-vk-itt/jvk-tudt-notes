import csv
import random
from animal import Animal


class Zoo:
    TRANSFER_COUNT = 10

    def __init__(self):
        self.animals = []
        self.weightUnits = "kg"

    def print_animals(self, animals=None, title="Animals in the Zoo", count=None):

        print()
        print("=======================================================")
        print(f" {title}")
        print("=======================================================\n")
        print("SPECIES                     NAME           AGE   WEIGHT")
        print("-------------------------------------------------------")

        if animals is None:
            animals = self.animals
        
        if count is not None:
            animals = animals[:count]

        for animal in animals:
            print(f"{animal.species: <28}{animal.name: <15}{animal.age: <6}{animal.weight: <4}")
        

    def add_animals(self, filename, header_row=True):
        try:
            with open(filename, "r") as f:
                csvRdr = csv.reader(f, delimiter=",")
                if header_row:
                    next(csvRdr)
                self.animals.extend([Animal(row[0], row[1], int(row[2]), int(row[3])) for row in csvRdr])
        except ValueError:
            print(f"An invalid value was found in file {filename}.")
        except IOError:
            print(f"An error occurred while reading the file {filename}.")        
        except FileNotFoundError:
            print(f"The file {filename} was not found.")

    def compile_transfer_list(self, filename):
        animals_for_transfer = random.sample(self.animals, k=Zoo.TRANSFER_COUNT)
        self.print_animals(animals=animals_for_transfer,
                            title=f"Animals to be transferred (writing to {filename})")
        try:
            with open(filename, "w") as f:
                csvWrt = csv.writer(f, delimiter=",")
                csvWrt.writerows(animals_for_transfer)
        except Exception as e:
            print(f"Error while writing to file: ", e)
        

    def convert_weights(self, units="kg"):
        conversion_factor = 1
        if units == "kg" and self.weightUnits == "lb":
            conversion_factor = 0.454
        elif units == "lb" and self.weightUnits == "kg":
            conversion_factor = 1/0.454

        if conversion_factor != 1:
            for a in self.animals:
                a.weight = round(a.weight * conversion_factor, 2)
            self.weightUnits = units
            
    def mean_weight(self):
        if len(self.animals) == 0:
            return 0
        return sum([a.weight for a in self.animals]) / len(self.animals)
            
