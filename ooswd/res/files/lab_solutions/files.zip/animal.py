class Animal:

    def __init__(self, species, name, age, weight):
        self.species = species
        self.name = name
        self.age = age
        self.weight = weight

    @property
    def species(self):
        return self._species

    @species.setter
    def species(self, species):
        if type(species) != str:
            raise TypeError("Species must be a string.")
        self._species = species

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name):
        if type(name) != str:
            raise TypeError("Name must be a string.")
        self._name = name

    @property
    def age(self):
        return self._age

    @age.setter
    def age(self, age):
        if type(age) != int:
            raise TypeError("Age must be an integer.")
        if age < 0 or age > 300:
            raise ValueError("Age must be a positive integer not greater than 300")
        self._age = age


    @property
    def weight(self):
        return self._weight

    @weight.setter
    def weight(self, weight):
        if type(weight) != int:
            raise TypeError("Weight must be an integer.")
        if weight < 0 or weight > 7000:
            raise ValueError("Weight must be a positive integer not greater than 7000")
        self._weight = weight

    def __str__(self):
        return f"species: {self.species}, name: {self.name}, age: {self.age}, weight: {self.weight}"