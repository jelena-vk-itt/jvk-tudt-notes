class Animal:
    def __init__(self, s, n, a, w):
        self.species = s
        self.name = n
        self.age = a
        self.weight = w

    def toList(self):
        return [self.species, self.name, self.age, self.weight]
