from animal import Animal
from csv_type_reader import CsvTypeReader
from zoo import Zoo

def list_multiline_str(lst):
    return "\n".join([el.__str__() for el in lst])

def dict_multiline_str(dictionary, pref):
    return "\n".join([f"{pref} {k}: {v}" for k, v in dictionary.items()])

def test_header(name):
    print(f"==================================================")
    print(f"============== {name} TESTS ====================")
    print(f"==================================================")
    print()

def test_begin(name, expect):
    print(f"----- TEST: {name} -----")
    print(f"Expected: {expect}")

def test_end():
    print(f"------ END TEST --------")
    print()

test_header("Animal")

test_begin("Working animal construction", "Data printed")
dog = Animal("dog", "Bobby", 3, 15)
print(dog)
test_end()

test_begin("Invalid species type", "TypeError")
try:
    cat = Animal(1, "Jenny", 10, 5)
except TypeError as e:
    print(e)
test_end()

test_begin("Invalid name type", "TypeError")
try:
    badger = Animal("badger", 0, 10, 10)
except TypeError as e:
    print(e)
test_end()

test_begin("Invalid age type", "TypeError")
try:
    hamster = Animal("hamster", "Professor", "j", 1)
except TypeError as e:
    print(e)
test_end()

test_begin("Invalid age (negative)", "ValueError")
try:
    hamster = Animal("hamster", "Professor", -2, 1)
except ValueError as e:
    print(e)
test_end()

test_begin("Invalid age (too big)", "ValueError")
try:
    hamster = Animal("hamster", "Professor", 1000, 1)
except ValueError as e:
    print(e)
test_end()

test_begin("Invalid weight (negative)", "ValueError")
try:
    hamster = Animal("hamster", "Professor", 2, -1)
except ValueError as e:
    print(e)
test_end()

test_begin("Invalid weight (too big)", "ValueError")
try:
    hamster = Animal("hamster", "Professor", 2, 10000)
except ValueError as e:
    print(e)
test_end()


test_header("Zoo")

test_begin("Zoo creation", "No problem")
zoo = Zoo()
test_end()


test_begin("Add an animal", "No problem")
zoo.add_animal(dog)
test_end()

test_begin("Add invalid type", "Error reported")
try:
    zoo.add_animal("dog")
except TypeError as te:
    print(te)
test_end()

test_begin("Add a few animals", "No problem")
zoo.add_animal(Animal("cat", "Miss", 3, 3))
zoo.add_animal(Animal("hamster", "Harry", 1, 1))
zoo.add_animal(Animal("dog", "Jackie", 10, 10))
test_end()

test_begin("Get and print transfer list (number ok)", "List printed")
for a in zoo.get_transfer_list():
    print(a)
test_end()

test_begin("Write transfer list", "Correct data in file")
zoo.write_transfer_list("animals_test.csv")
test_end()

#############################################
test_header("CsvTypeReader")
test_data = [
    ["Read file with [str]", "List of lists printed, no problems", "data.csv", [str]],
    ["Read file with [str, int, float]", "List of lists printed, no problems", "data2.csv", [str, int, float]],
    ["Read file with [str, int, float]", "List of 1 list only, 2 problems", "data3.csv", [str, int, float]],
    ["Read file with no new line at end", "List of lists, no problems", "data4.csv", [str]],
    ["Read file with commas in values", "List of lists, no problems", "data5.csv", [str, str, int, int]]]
for t in test_data:
    test_begin(t[0], t[1])
    ctr = CsvTypeReader()
    ctr.read_csv(t[2], t[3])
    print(f"Data:\n{dict_multiline_str(ctr.get_data(), "Line")}")
    print(f"Problems:\n{dict_multiline_str(ctr.get_problems(), "Line")}")
    test_end()


#############################################
# NOT WRITTEN DURING LAB DEMO BUT LATER
test_header("Zoo methods")

test_begin("Print all, convert weights to pounds, print all, convert back to kilos, print all", "No errors")
print(zoo)
print()
zoo.convert_weight(False)
print(zoo)
print()
zoo.convert_weight(True)
print(zoo)
print()
test_end()

test_begin("Get mean weight for dogs", "No error")
print(zoo.mean_weight("dog"))
test_end()
test_begin("Get and print mean weight for badgers", "Should be None")
print(zoo.mean_weight("badger"))
test_end()