def list_multiline_str(lst):
    return "\n".join([el.__str__() for el in lst])

def dict_multiline_str(dictionary, pref):
    return "\n".join([f"{pref} {k}: {v}" for k, v in dictionary.items()])
