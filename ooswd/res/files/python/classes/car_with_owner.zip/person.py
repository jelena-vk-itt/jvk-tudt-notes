class Person:
    def __init__(self, n, a):
        self.name = n
        self.address = a

    def getName(self):
        return self.name