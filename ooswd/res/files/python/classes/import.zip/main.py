from person import Person
from address import Address

p1 = Person("Bob", "Builder", Address("1", "Site", "Btown", "BB", "XYZ123"))
p1.print()

p2 = Person("Annie", "Apple", Address("2", "The Orchard", "Atown", "AA", "ABC789"))
p2.print()
