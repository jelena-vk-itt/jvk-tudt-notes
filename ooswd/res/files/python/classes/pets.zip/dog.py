from pet import Pet

class Dog(Pet):

    def __init__(self, training_times):
        super().__init__()
        self._training_times = training_times

    def feed_times(self):
        return [19]

    def walk_times(self):
        return [8, 18]

    def __str__(self):
        return super().__str__() + f"\nTraining times: {self._training_times}"

