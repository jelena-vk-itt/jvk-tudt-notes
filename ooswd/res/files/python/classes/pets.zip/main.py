from pet import Pet
from dog import Dog
from cat import Cat
print("--- Pet ---")
pet = Pet()
print(pet)
pet.set_alarms()
print(pet)
print("--- Dog ---")
dog = Dog("6, 17")
print(dog)
dog.set_alarms()
print(dog)