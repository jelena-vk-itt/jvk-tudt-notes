from pet import Pet

class Cat(Pet):

    def feed_times(self):
        return [8]