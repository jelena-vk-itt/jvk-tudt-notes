class Pet:
    def __init__(self):
        self._alarms = {
            "feed": [],
            "walk": []
        }

    def feed_times(self):
        return [12]

    def walk_times(self):
        return []

    def set_alarms(self):
        self._alarms["feed"] = self.feed_times()
        self._alarms["walk"] = self.walk_times()

    def __str__(self):
        return (f"Feed alarms: {self._comma_separated_alarms("feed")}\n"
                f"Walk alarms: {self._comma_separated_alarms("walk")}")

    # helper function
    def _comma_separated_alarms(self, alarm_type):
        return ", ".join([str(num) for num in self._alarms[alarm_type]])

