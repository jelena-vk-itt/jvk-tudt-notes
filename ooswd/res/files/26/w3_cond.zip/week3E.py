age = int(input("Please enter your age: "))
hasProvisional = input("Do you have a provisional licence (y/n): ")
# version 1
if age >= 17:
   if hasProvisional == "y":
      print("You are eligible for a driving licence.")
   else:
      print("You are not eligible for a driving licence.")
else:
   print("You are not eligible for a driving licence.")

# version 2
if age >= 17 and hasProvisional == "y":
   print("You are eligible for a driving licence.")
else:
   print("You are not eligible for a driving licence.")