cont_string = input("Please enter a string: ")
sub_string = input("Please enter the substring to search for: ")

positions = []
start_index = 0
pos = cont_string.find(sub_string, start_index)
while pos != -1:
   positions.append(pos)
   start_index = pos + len(sub_string)
   pos = cont_string.find(sub_string, start_index)

if len(positions) == 0:
   print(f'The substring was not found in the string.')
else:
   positions_string = ''
   for pos in enumerate(positions):
       if pos[0] == 0:
          positions_string += str(pos[1])
       elif pos[0] == len(positions) - 1:
          positions_string += ' and ' + str(pos[1])
       else:
          positions_string += ', ' + str(pos[1])

   num_postfix = 's' if len(positions) > 1 else ''

   print(f'The substring appears at position{num_postfix} {positions_string}.')

