age = int(input("Please enter your child's age: "))
school = input("Please enter your child's primary school: ")

if age >= 12 and (school == "A" or school == "B"):
    print("Your child has a place")
else:
    print("Your child does not have a place")

# ALTERNATIVE WAY (e.g. if many feeder schools)
if age >= 12 and school in ['A', 'B', 'C', 'D']:
    print("Your child has a place")
else:
    print("Your child does not have a place")
