
x = int(input("Enter a number, please: "))

if x > 3:
   print("x is greater than 3")
   print("And that's all")
else:
   print("x is not greater than 3")