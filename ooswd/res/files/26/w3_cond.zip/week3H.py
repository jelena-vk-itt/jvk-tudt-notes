#     Communicate appropriately with the customer, printing prompts when needed

#     Calculate the amount due, based on a scoop price of €1.20
#     Ask the customer if they are over 65 and apply a discount of 20% to the price if they are
#     Print the amount due

num_scoops = int(input("How many scoops would you like: "))
amount_due = 1.2 * num_scoops
over_65 = input("Are you over 65 (y/n)? ")

if over_65 == 'y':
    amount_due *= 0.8
    print("You are eligible for a 20% discount :-).")
else:
    print("You are not eligible for a 20% discount :-(.")

print(f"Amount due: €{amount_due:.2f}")
