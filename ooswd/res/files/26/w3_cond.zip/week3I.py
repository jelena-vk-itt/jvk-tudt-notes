general = "Dumbo"
fifteen = "When we were 15"
eighteen = "Reservoir Dogs"

age = int(input("Please enter your age: "))

print("Films for you: ")

if age > 18:
    print(general)
    print(fifteen)
    print(eighteen)
elif age > 15:
    print(general)
    print(fifteen)
else:
    print(general)

print("--------------")

# ALTERNATIVE (no repetition)
print(general)

if age > 15:
    print(fifteen)

if age > 18:
    print(eighteen)
