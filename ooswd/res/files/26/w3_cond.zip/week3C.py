enrolment_list = []
name = input("Please enter your name: ")

if name != "":
    # add person to enrolment list
    enrolment_list.append(name)
else:
    print("Empty names are not allowed. You are not enrolled.")

