# input name
name = input("Please input your first name: ")

# input surname
surname = input("Please input your surname: ")

# print out, with correct capitalisation
# Your name is n s
print(f"Your name is {name.capitalize()} {surname.capitalize()}")