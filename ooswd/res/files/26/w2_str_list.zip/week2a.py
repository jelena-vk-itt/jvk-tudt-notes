# input name
name = input("Please input your first name: ")

# input surname
surname = input("Please input your surname: ")

# print results of investigation
print(f"The name comes before the surname in alphabetical order: {name.lower() < surname.lower()}")
print(f"The name contains 'a' or 'A': {'a' < name.lower()}")
print(f"The surname contains 't' or 'T': {'t' in surname or 'T' in surname}")