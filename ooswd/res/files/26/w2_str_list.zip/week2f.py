from random import choice

names = "Amy, Ben, Con, Dan, Emi, Fi"
nameList = names.split(sep=', ')
winner = choice(nameList)

print(f"The raffle winner is {winner}!")