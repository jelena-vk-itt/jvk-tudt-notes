# input name
word = input("Please input a five-letter word: ")

inv_word = word[4] + word[3] + word[2] + word[1] + word[0]

print(inv_word)