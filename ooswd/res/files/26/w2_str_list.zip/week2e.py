namesString = "AMY, bob, cOn, DAn"
namesList = namesString.split(sep=', ')

namesList[0] = namesList[0].capitalize()
namesList[1] = namesList[1].capitalize()
namesList[2] = namesList[2].capitalize()
namesList[3] = namesList[3].capitalize()

tidiedNamesString = ", ".join(namesList)

print(tidiedNamesString)