import copy

# input name
name = input("Please input your first name: ")
surname = input("Please input your surname: ")
dob = input("Please input your date of birth: ")
house_num = input("Please input your house number: ")
street = input("Please input your street name: ")
town = input("Please input your city/town name: ")

data1 = [name, surname, dob, [house_num, street, town]]
print(F"The data are: \n{data1}")
print("The data are: \n{0}".format(data1))

country = input("Please input your country of birth: ")
data2 = data1 + [country]

print(data2)

print(f"'Ireland' is in the list: {'Ireland' in data2}")
print(f"'France' is in the list: {'France' in data2}")

print(f"{data2[0]} lives at number {data2[3][0]}.")

print(f"The list in data2 is the same as ['Ann', 'Thompson', '01/01/01', ['7', 'Main St.', 'Dublin'], 'Ireland']: {data2 == ['Ann', 'Thompson', '01/01/01', ['7', 'Main St.', 'Dublin'], 'Ireland']}")
print(f"The list in data2 is the same as ['Ann', 'Thompson', '01/01/01', ['7', 'Main St.', 'Cork'], 'Ireland']: {data2 == ['Ann', 'Thompson', '01/01/01', ['7', 'Main St.', 'Cork'], 'Ireland']}")

data2[0] = 'Annie'
data2[3][0] = '7a'
data2.pop(-1)

print(f"New list: {data2}")

data3 = copy.deepcopy(data2)

data3[2] = '02/02/02'
data3[3][0] = '8'
data3[3][1] = 'Noth Boulevard'
data3[3][2] = 'Cork'

print(f"The two people are: \n{data2}\n{data3}")
