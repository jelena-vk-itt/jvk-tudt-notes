# input name
char = input("Please input a character: ")
enck = int(input("Please input a encryption key: "))

char_code = ord(char)
enc_code = char_code + enck
enc_char = chr(enc_code)

print("Your character encoded is: " + enc_char)

