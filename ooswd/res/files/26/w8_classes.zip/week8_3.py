class TwoNumbersV2:
    heading = "THE TWO NUMBERS"

    def __init__(self, num1, num2):
        self.num1 = num1
        self.num2 = num2

    def print(self):
        print("")
        if self.heading != "":
            print(f"----- {self.heading} -----")
        print("num1 is: ", self.num1)
        print("num2 is: ", self.num2)

twoNumObj = TwoNumbersV2(3, 4)

print(f"Object heading before change {twoNumObj.heading}")
twoNumObj.heading = "NEW HEADING"

print(f"Object heading after change {twoNumObj.heading}")

print(f"The class heading is {TwoNumbersV2.heading}")

twoNumObj.print()
