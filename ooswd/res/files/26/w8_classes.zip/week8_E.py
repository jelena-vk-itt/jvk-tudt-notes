import copy

class Address:
    def __init__(self, n, s, t):
        self.number = n
        self.street = s
        self.town = t

    def print(self):
        print("Address: {} {}, {}".format(self.number, self.street, self.town))

class Person:
    def __init__(self, n, s, a):
        self.name = n
        self.surname = s
        self.address = a

    def print(self):
        print(f"Name: {self.name} {self.surname}")
        self.address.print()

    def move(self):
        self.address.number += 1

sharedAddress = Address(1, "Main Street", "Smalltown")
adam = Person("Adam", "Smith", sharedAddress)
becky = Person("Becky", "Chandler", copy.copy(sharedAddress))
adam.print()
becky.print()

adam.move()
adam.print()
becky.print()