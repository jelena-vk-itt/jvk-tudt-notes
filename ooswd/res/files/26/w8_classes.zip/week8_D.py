class Address:
    def __init__(self, n, s, t):
        self.number = n
        self.street = s
        self.town = t

    def print(self):
        print("Address: {} {}, {}".format(self.number, self.street, self.town))

class Person:
    def __init__(self, n, s, a):
        self.name = n
        self.surname = s
        self.address = a

    def print(self):
        print(f"Name: {self.name} {self.surname}")
        self.address.print()

person = Person("Adam", "Smith", Address(1, "Main Street", "Smalltown"))
person.print()