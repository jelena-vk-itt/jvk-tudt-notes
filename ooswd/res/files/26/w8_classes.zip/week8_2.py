class TwoNumbers:
    def __init__(self, num1, num2):
        self.num1 = num1
        self.num2 = num2

    def print(self, heading=""):
        print("")
        if heading != "":
            print(f"----- {heading} -----")
        print("num1 is:", self.num1)
        print("num2 is:", self.num2)

tn_obj = TwoNumbers(2, 7)
tn_obj.print("THE TWO NUMBERS")
