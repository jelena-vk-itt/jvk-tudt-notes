class ThreeFour:
    def __init__(self):
        self.x = 3
        self.y = 4

    def print(self):
        print("x is: ", self.x)
        print("y is: ", self.y)

tf_obj = ThreeFour()

print(tf_obj.x)
print(tf_obj.y)

tf_obj.print()


