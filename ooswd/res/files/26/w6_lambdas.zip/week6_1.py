# some names
names = ["ben", "con", "ann", "dan"]
# define a lambda expression that returns the
# index in the list 'names' for the given string value
# it refers to the variable names
get_index_for_name = lambda nm: names.index(nm)
# use it
print(get_index_for_name('ann'))
print(get_index_for_name('ben'))

# some scores
scores = [23, 67, 34, 12]
# define a lambda expression that returns the
# value in the list 'scores' corresponding by position
# to the given value in the list 'names'
get_score_for_person = lambda nm: scores[names.index(nm)]
print(get_score_for_person("ben"))
print(get_score_for_person("dan"))
