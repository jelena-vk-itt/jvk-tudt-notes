import math

def print_numbers(num_list):
    print(", ".join([str(num) for num in num_list]))

number_list = [1, 2, 3, 5, 7]

print_numbers(number_list)

print_numbers([number**2 for number in number_list])
print_numbers([round(math.sqrt(number), 2) for number in number_list])
print_numbers([number for number in number_list if number % 2 == 1])
