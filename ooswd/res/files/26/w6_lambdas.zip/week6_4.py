names = ['Anne', 'Ben', 'Con', 'Danny', 'Emily', "Finn", "George"]

# create a sublist of names that contain the letter n (or N)
print([name for name in names if name.lower().count('n') > 0])

# create a sublist of names that contain one vowel and map to lowercase names
print([n.lower() for n in names if len([l for l in n if l.lower() in 'aeiou']) == 1])



