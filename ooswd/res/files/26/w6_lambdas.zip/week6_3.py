names = ['Alice', 'Bob', 'Con', 'Derval', 'Evan']
new_lst = [len(name) for name in names if len(name) < 5]
print(sum(new_lst) + (len(new_lst) - 1) * 2)
