names = ['Amy', 'Ben', 'Con', 'Dan', 'Emi']

def less_than_two_vowels(name):
    return len([letter for letter in name if letter in 'aeiouAEIOU']) < 2

print(
less_than_two_vowels("lend"),
less_than_two_vowels("kiwi"),
less_than_two_vowels("peekaboo"))

print(names)
print([name.lower() for name in names if less_than_two_vowels(name)])