scores_for_names = { "ben": 23, "con": 67, "ann": 34, "dan": 12 }
get_score_for_person = lambda nm: scores_for_names[nm]

print(f"Con's score is {get_score_for_person('con')}")



