class Person:
    def __init__(self, n, s):
        self.name = n
        self.surname = s

    def __str__(self):
        return "name: " + self.name + "\nsurname: " + self.surname

    def get_fullname(self):
        return self.name + " " + self.surname


class Employee(Person):
    def __init__(self, n, s, en):
        super().__init__(n, s)
        self.employeeNumber = en

    def __str__(self):
        return super().__str__() + "\nemployee number: " + str(self.employeeNumber)

p = Person("Bob", "Cratchit")
print(p)
print("Full name: ", p.get_fullname())

print()
e = Employee("Jane", "Lane", 1)
print(e)
print("Full name: ", e.get_fullname())