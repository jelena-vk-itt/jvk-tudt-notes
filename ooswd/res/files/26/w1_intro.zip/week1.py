# n = 100
# print('*' * n)
# print('*' + (n-2) * ' ' + '*')
# print('*' + (n-2) * ' ' + '*')
# print('*' + (n-2) * ' ' + '*')
# print('*' * n)

name = input("Input your name: ")
height = int(input("Input your height in cm: "))
heightM  = height / 100
print("Hi {}, your height in meters is {}".format(name, heightM))
print(f'Hi {name}, your height in meters is {heightM}')