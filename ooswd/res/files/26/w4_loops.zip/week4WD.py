import random

random_number = random.randint(1, 11)
while random_number != 11:
    print(random_number)
    random_number = random.randint(1, 11)
