import random
iteration_count = random.randint(1, 10)

count = 1
while count <= iteration_count:
    print(1)
    count += 1