
print("**********")
count = 1
while count <= 4:
    print("*        *")
    count += 1
print("**********")
