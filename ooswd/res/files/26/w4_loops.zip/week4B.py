import random

count = 1
while count <= 10:
    print(random.randint(1, 11))
    count += 1