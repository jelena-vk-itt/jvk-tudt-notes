word_list = []

word = input("Please enter a word, '.' to stop or '---' to exit the program: ")
while word != '.':
    if word == '---':
        break
    if word.isalpha():
        word_list.append(word)

    word = input("Please enter another word, '.' to stop or '---' to exit the program: ")

else:
    print('\n'.join(word_list))
