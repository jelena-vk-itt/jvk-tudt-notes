# Then, using a for loop, it should invert the order of the characters in the word. Finally, it should print out the string resulting from the inversion, the output of expression inputString[::-1] and the result of comparing the two.

input_string = input("Please enter a string: ")

output_string = ""
for char in input_string:
    output_string = char + output_string

print(f"output_string: {output_string}")
print(f"input_string[::-1]: {input_string[::-1]}")
print(f"Strings are equal: {output_string == input_string[::-1]}")