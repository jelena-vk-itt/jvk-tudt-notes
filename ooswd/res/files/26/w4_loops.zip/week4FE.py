# using CS-11 from the while loop page
for count in range(1, 101):
   if '0' in str(count):
      continue
   print(count)