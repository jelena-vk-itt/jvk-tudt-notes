import random

for count in range(0, 11):
    print(random.randint(1, 11))