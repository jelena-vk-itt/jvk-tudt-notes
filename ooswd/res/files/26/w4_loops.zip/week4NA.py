columnCount = 3
rowCount = 3
product_list_2d = []
for rowNum in range(1, rowCount + 1):
    row_list = []
    for colNum in range(1, columnCount + 1):
        row_list.append(rowNum * colNum)
    product_list_2d.append(row_list)

print(product_list_2d)