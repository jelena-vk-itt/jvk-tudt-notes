# assuming unique values
fruit = ['apple', 'orange', 'banana', 'pear', 'peach']
for f in fruit:
    print(f"{fruit.index(f) + 1} {f}")