
word = input("Please enter a word, '.' for stop: ")
while word != '.':
    if word.isalpha():
        list_of_chars = list(word.upper())
        print(' '.join(list_of_chars))

    word = input("Please enter another word, '.' for stop: ")
