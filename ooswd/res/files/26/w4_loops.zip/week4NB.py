import random
n = random.randint(0, 5)
while n != 0:
    upper_rand = random.randint(6, 10)
    for i in range(n, upper_rand):
        print(str(i) + " ", end="")
    print("")
    n = random.randint(0, 5)