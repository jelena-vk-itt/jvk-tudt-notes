import random

while input("Do you want to count tries until a 5 (y/n)? ") == 'y':
    counter = 1

    while random.randint(0, 5) != 5:
        counter +=1

    print(counter)
