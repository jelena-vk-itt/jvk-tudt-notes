alert("Hello from the file js_in_html_1.js!");
