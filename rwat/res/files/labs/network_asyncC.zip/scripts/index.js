const FILE_LIST = ["reference.json", "data3.json"];

// insert a data item as a row in the HTML table
function insert_data_rows(table, data_rows) {
  data_rows.forEach((data_row) => {
    let rowEl = document.createElement("tr");
    table.appendChild(rowEl);
    data_row.forEach((data_item) => {
      let tdEl = document.createElement("td");
      rowEl.appendChild(tdEl);
      tdEl.appendChild(document.createTextNode(data_item));
    });
  });
}

// process the contents of a json file
function process_response_obj(obj) {
  const ret = [[], ""];
  if ("data" in obj) {
    for (let data_item of obj.data) {
      ret[0].push([...data_item.name.split(" "), data_item.id]);
    }
  }
  if ("data_location" in obj) {
    ret[1] = obj.data_location;
  }
  return ret;
}

// The implementations below will work with any number of
// json data files, referencing any number of json data files.

// sync XMLHttpRequest
const SYNC_TAB = document.getElementById("sync");
FILE_LIST.forEach(function getnproc_file_xhr_sync(file_name) {
  const req = new XMLHttpRequest();
  req.open("GET", "data/" + file_name, false);
  req.send(null);

  if (req.status === 200) {
    let ret = process_response_obj(JSON.parse(req.responseText));
    insert_data_rows(SYNC_TAB, ret[0]);
    if (ret[1]) {
      getnproc_file_xhr_sync(ret[1]);
    }
  } else {
    console.error("Failed to get " + file_name + " with synchronous xhr.");
  }
});

// async XMLHttpRequest
const ASYNC_TAB = document.getElementById("async");
// Because of everything being handled by callback functions, without
// a JavaScript mechanism for the synchronisation of their outcomes,
// we need to set up a mechanism that will allow us to process the
// data from the files in the correct order. The files will be assigned
// an orderable id (0, 1, 2... in the top layer of files e.g.
// reference.json is 0 and data3.json is 1; the next layer, referenced
// by files in the first layer have ids 0.0, 0.1, ... e.g. data1.json
// is 0.0 and there is no 1.x since data3.json does not reference
// any files; similarly, data2.json is 0.0.0) which can be used for
// sorting the data from the different files, regardless of when they
// come in. The data constant array contains pairs of values:
// [id, file_data]. A pair is created when a request is sent and the
// file_data set when the response comes in. At the same time, the
// responses coming in are counted with countResponses. When
// this reaches the length of data, we know that all the responses
// are in without any outstanding requests.
const data = [];
let countResponses = 0;
(function get_data_from_files_asyncxhr(file_list, id_base = "") {
  // process all the files at the same level
  file_list.forEach((file_name, index) => {
    // set up the index and id-data pair, then push pair into data
    const id = id_base + index;
    const idDataPair = [id, []];
    data.push(idDataPair);
    const req = new XMLHttpRequest();
    req.addEventListener("load", (e) => {
      // count response regardless of status
      ++countResponses;
      if (e.target.status === 200) {
        let ret = process_response_obj(JSON.parse(e.target.responseText));
        // push the data from this file into the data structure
        idDataPair[1].push(...ret[0]);
        // if more files are specified in the json, process that next 
        // level of files using a recursive call
        if (ret[1]) {
          get_data_from_files_asyncxhr([ret[1]], id);
        }
        // if responses are in for all the requests sent out, sort the responses
        // based on id alphabetical order, then concatenate all the stored data 
        // and render into the table - devising a way such as this of detecting
        // the end of file reading and ordering the retrieved data will not be
        // required with the fetch function and promises
        if (countResponses == data.length) {
          data.sort((a, b) => a[0] > b[0] ? 1 : b[0] > a[0] ? -1 : 0);
          insert_data_rows(ASYNC_TAB, [].concat(...data.map((item) => item[1])));
        }
      } else {
        console.error("Failed to get " + file_name + " with asynchronous xhr.");
      }
    });
    req.open("GET", "data/" + file_name);
    req.send(null);
  });
  return data;
})(FILE_LIST);


// fetch
const FETCH_TAB = document.getElementById("fetch");
// all the files are fetched in parallel, asynchronously
async function get_data_from_files_fetch(filenames) {
  // Promise.allSettled is used so we don't have to worry about waiting for all
  // the promises explicitly. To get the array of promises to pass into the
  // Promise.allSettled call, we map each filename to a promises returned by 
  // the fetch - then chain that fetches and processes the file contents. The
  // mapping function is asynchronous, allowing parallel fetching to take place.
  return Promise.allSettled(filenames.map(async (filename) => {
    return await fetch("data/" + filename)
      // the first then for each file processes the response
      .then((resp) => {
        if (resp.ok) {
          return resp.json();
        } else {
          console.error("Failed to get " + filename + ", response status: " + resp.status);
        }
      }, (error) => { console.error(error); })
      // the second then for each file gets the data out of the response
      .then(async (resp_obj) => {
        if (resp_obj) {
          let ret = process_response_obj(resp_obj);
          // If other files are specified in the currently processed file, 
          // then the json fetching and processing function 
          // (get_data_from_files_fetch) is called again (recursion).
          // To ensure the correct order of data rendering, we await for 
          // this call to complete and concatenate the resulting data
          // onto the data from the current file.
          if (ret[1]) {
            return ret[0].concat(await get_data_from_files_fetch([ret[1]]));
          }
          // if no other files are specified, then just return the data 
          // from the current file
          return ret[0];
        }
        // if the response object was undefined i.e. the fetch failed,
        // return an empty array to allow the other files to be processed
        return [];
      }, (error) => { console.error(error); })

  }))
    // once all the promises at this level of files are settled,
    // get the data out of the promise array, concatenate and return
    .then((promise_array) =>
      [].concat(...promise_array.map((promise) => promise.value)),
      (error) => { console.error(error); });
}
// call get_data_from_files_fetch on the top level file list, await and render
(async function render2() {
  try {
    insert_data_rows(FETCH_TAB, await get_data_from_files_fetch(FILE_LIST));
  } catch (error) { console.error(error); }
})();

