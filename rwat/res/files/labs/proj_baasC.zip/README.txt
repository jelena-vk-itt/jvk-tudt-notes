The node_modules subdirectory has not been included in this zip file to keep the size manageable.

The subdirectory can be restored by running the command 'npm install' in the directory containing this file.