export default {
  base: "",
};
