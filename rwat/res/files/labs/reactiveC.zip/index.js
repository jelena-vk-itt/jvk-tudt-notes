import { delay, filter, fromEvent, map, merge, of, pairwise, scan } from 'rxjs';

// The task is to identify groups of mouse-clicks (referred to as
// click-groups from here on) and to display the length of the last
// identified click-group on the HTML page.

// We are going to set a minimum time between clicks of 0.5 seconds to
// represent the spacing between click-groups. Any clicks less than 0.5
// seconds apart we will consider to belong to the same click-group.

// The solution that follows is one way of finding the click groups, but there
// may be a shorter or simpler one!

// Create an observable with events that are the indices of clicks on the page
// (the map function converts the click event to an index).
const clickIndices = fromEvent(document, 'click').pipe(map((_, i) => i));

// Merge the first observable with another one that has the same
// events but delayed by half a second and with 0.5 added to the index.
// An additional values of -1 and -0.5 are added in at the beginning,
// of the sequence, for reasons that will be explained later.
// For clicks more than 0.5 seconds apart, the sequence will be:
// -1, -0.5, 0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5..., however, with some
// clicks less, than 0.5 seconds apart, the sequence will be a bit
// 'jumbled up', e.g.: -1, -0.5, 0, 0.5, 1, 2, 1.5, 3, 2.5, 3.5, 4,
// 5, 4.5, 5.5, 6, 6.5... In this last example the events (denoted by
// their indices) are grouped as follows: (0), (1, 2, 3), (4, 5), (6)...
//
// This information, on how the clicks are grouped, was extracted from
// the sequence in the following way: any whole number x that is
// followed only by non-whole numbers up until the number x + 0.5
// is the closing index of a click-group***. This is the 0.5-second-
// minimum rule for the time between click groups, but expressed in
// terms of the values in the created sequence. This expression of
// the rule will allow algorithmic extraction of groups (this was
// the reason for the creation of the sequence with the interspersed
// i + 0.5 values). In our example, the closing indices of click-
// groups that result from applying the rule *** are 0, 3, 5, 6...
// There is also the artificially added-in index -1, but this is
// not mentioned as it is not the close of a real click-group and
// is only a technical artefact needed for the algorithm.
// The groupings shown above i.e. (0), (1, 2, 3), (4, 5), (6)...
// follow from these click-group closing indices and from these
// the click-group lengths are directly calculable.
//
// Now that we have a defined path to finding the click-group lengths,
// all we need to do is to find the RxJS operations that will allow
// us to perform the necessary transformations on the sequence to
// implement that path.
const transformedClickIndices = merge(
    of(-1, -0.5),
    clickIndices,
    clickIndices.pipe(delay(500), map((v) => v + .5))
).pipe(
    // --> Step 1: Use operation pairwise pairs from adjacent values.
    // This will later allow us to make comparisons between values in
    // adjancent events. In the example this results in the sequence:
    // [-1, -0.5], [-0.5, 0], [0, 0.5], [0.5, 1], [1, 2], [2, 1.5], 
    // [1.5, 3], [3, 2.5], [2.5, 3.5], [3.5, 4], [4, 5], [5, 4.5], 
    // [4.5, 5.5], [5.5, 6], [6, 6.5]...
    pairwise(),
    // --> Step 2: Use operation scan to apply an aggregation function to
    // the events and transform each event to the aggregate value obtained
    // at that event. The specific function we use converts any non-integer 
    // value on the left of an event pair to the last integer value that 
    // appeared on the left of a pair in the preceding sequence. We do 
    // this because we are interested to compare non-integer values
    // to the last integer value (to check our criterion *** defined above).
    // In the example, this results in the following sequence:
    // [-1, -0.5], [-1, 0], [0, 0.5], [0, 1], [1, 2], [2, 1.5], [2, 3],  
    // [3, 2.5], [3, 3.5], [3, 4], [4, 5], [5, 4.5], [5, 5.5], [5, 6], [6, 6.5]...
    scan(([a1, _], [c1, c2]) => [Number.isInteger(c1) ? c1 : a1, c2], [-1, 0.5]),
    // --> Step 3: In this step we use filter to leave out any non-integer
    // values following an integer value x and not equal to x + 0.5 (such
    // non-integer values will be x-1+0.5 or less and always less than x).
    // This results in the following sequence in our example:
    // [-1, -0.5], [-1, 0], [0, 0.5], [0, 1], [1, 2], [2, 3], [3, 3.5],
    // [3, 4], [4, 5], [5, 5.5], [5, 6], [6, 6.5]...
    filter(([c1, c2]) => c2 > c1),
    // --> Step 4: Now that we have filtered out the non-interesting events,
    // we can use map to get rid of the left value in each pair, as those
    // were only 'helper' values. The example sequence becomes:
    // -0.5, 0, 0.5, 1, 2, 3, 3.5, 4, 5, 5.5, 6, 6.5...
    map(([_, c2]) => c2),
    // --> Step 5: What we have left are the click sequence, interspersed by
    // group boundaries represented by non-integer values. The difference
    // of the boundary values will give us the group sizes, which means that
    // we can filter out all the integer values and in the example are left 
    // with: -0.5, 0.5, 3.5, 5.5, 6.5...
    filter(c => !Number.isInteger(c)),
    // --> Step 6: We use pairwise again to form pairs and in the example
    // these are: [-0.5, 0.5], [0.5, 3.5], [3.5, 5.5], [5.5, 6.5]...
    // The purpose of the inserted -1 and -0.5 values at the beginning
    // is now obvious: it was so that the first group would not get 'lost'
    // due to no lower boundary.
    pairwise(),
    // --> Step 7: We use map to get the differences between pairs, completing
    // the transformation algorithm. In the example the differences are:
    // 1, 3, 2, 1...
    map(([c1, c2]) => Math.round(c2 - c1))
    // We subscribe to the resulting observable, placing the length of the
    // latest group as a number on the HTML page.
).subscribe(x => document.body.innerHTML = "<h1>" + x + "</h1>");


